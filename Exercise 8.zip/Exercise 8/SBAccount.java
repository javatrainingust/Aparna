package com.training.ustjava;

public class SBAccount extends Account {

	public float balance=100000;
	float duration=1;
	//InterestCalculator ic= new InterestCalculator();

	public float getbalance() {
		return balance;
	}

	/*public void calculateInterest(float amount,ICalculator calculator){

        float sbinterest=calculator.interestCalculation( amount,duration);
  System.out.println(sbinterest);
  }




}*/
	public void withdrawMoney(float amountWithdrawn)
	{
		balance=balance- amountWithdrawn;
		System.out.println("Account balance after withdrawing " +amountWithdrawn + "is :" +balance);
	}
}

/*
	public void CalculateInterest()
	{
		this.ic.SavingsAccountInterest(30000, 1);
	}
 */

