package com.training.ust.service;

import com.training.ustjava.Account;
import com.training.ustjava.FDAccount;
import com.training.ustjava.InterestCalculator;
import com.training.ustjava.SBAccount;

public class GeneralService {

	public static void main(String[] args) {

		FDAccount fd=  new FDAccount();
		fd.CalculateInterestFD(1000,2);

		SBAccount sb= new SBAccount();
		sb.withdrawMoney(2000);

		Account[] a= {new Account(), fd, sb};

		InterestCalculator calculator = new InterestCalculator();

		for(Account account :a){

			account.calculateInterest(1000,calculator);

			if(account instanceof FDAccount){

				FDAccount fda = (FDAccount)account;

				fda.CalculateInterestFD(1000,1); 
			}
		}
	}
}
