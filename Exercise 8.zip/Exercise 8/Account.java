package com.training.ustjava;


public class Account {

	private int accountnumber;
	private String holdername;
	private float balance=100000;

	public int getaccountnumber() {
		return accountnumber;
	}
	public void setaccountnumber(int accountnumber) {
		this.accountnumber = accountnumber;
	}
	public String getholdernamee() {
		return holdername;
	}
	public void setholdername(String holdername) {
		this.holdername = holdername;
	}
	
	public void calculateInterest(float amount,ICalculator calculator){
		
		double fdinterest=calculator.CalculateInterest(amount, 1);
		System.out.println(fdinterest);
		}
}