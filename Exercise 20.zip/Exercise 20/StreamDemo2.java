/**
 * StreamDemo2
 * 
 * This class is created to convert the array into stream using Arrays.stream() method.
 * 
 * 09/10/2020
 */

package com.ust.training.stream;

import java.util.Arrays;
import java.util.stream.Stream;


public class StreamDemo2 {

	public static void main(String[] args) {

		//Inserting names into stream and converting it to stream and printing
		String[] array= {"Vinoth","Suresh","Jane","Roshan"};
		Stream<String> myStream= Arrays.stream(array);
		
		myStream.forEach((n)->System.out.println(n));

		}

	}
