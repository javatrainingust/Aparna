/**
 * StreamDemo1
 * 
 * This class is created to convert an arraylist into stream and print the count
 * 
 * 09/10/2020
 */

package com.ust.training.stream;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Stream;


public class StreamDemo1 {

	public static void main(String[] args) {
		
		//Initializing the list and adding objects to it
		List<String> list= new ArrayList<String>();
		list.add("Vinoth");
		list.add("Suresh");
		list.add("Jane");
		list.add("Roshan");
		list.add("Anu");
		
		//Converting list into stream and printing the count
		Stream<String> myStream= list.stream();

		long stream= myStream.count();

		System.out.println(stream);

	}

}
