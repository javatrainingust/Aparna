package com.ust.java.collections;

/**
 * Main class for Cat 
 * 05/10/2020
 */

import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;

public class Main {

	public static void main(String[] args) {
			
			List cats= new ArrayList<Cat>();
			Cat cat1= new Cat("Lucy", 3);
			Cat cat2= new Cat("Pikku", 8);
			Cat cat3= new Cat("Kitty", 1);
			Cat cat4= new Cat("Albert", 10);
			
			cats.add(cat1);
			cats.add(cat2);
			cats.add(cat3);
			cats.add(cat4);
			
			
			  Iterator<Cat> i1= cats.iterator(); 
			  while(i1.hasNext()) 
			  { 
				  System.out.println(i1.next());
			  }
			  
			  /*
				 * for( int i=0; i<cats.size();i++) { Cat obj = (Cat)cats.get(i);
				 * System.out.println(" Cats are: " +obj.name +" "+obj.age); }
				 */
			  
			  Collections.sort(cats);
				
				System.out.println(cats);
			
			
		}

}
