package com.ust.java.collections;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class Students {

	public static void main(String[] args) {
		
		List students= new ArrayList<String>();
		students.add("Vivek");
		students.add("Vijay");
		students.add("Ajith");
		students.add("Surya");
		
		for( int i=0; i<students.size(); i++)
		{
			System.out.println("The names are :" +students.get(i));
		}
		
		Collections.sort(students);
		
		System.out.println();
		System.out.println("The sorted list");
		
		for( int i=0; i<students.size(); i++)
		{
			System.out.println("The names are :" +students.get(i));
		}
	}

}
