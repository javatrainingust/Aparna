package com.training.ustjava.codingstn;

/**
 * 
 *CheckRenew 
 *
 *CheckRenew is interface 
 *
 *30-09-2020
 */

public interface CheckRenew {

		public void autoRenewable(int tenure);

	}