/**
 * 
 * SBAccountController
 * 
 * Controller class for SBAccountDAOImpl
 * 
 * 15-10-2020
 */

package com.training.ust.controller;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.training.ust.service.SBAccountService;
import com.training.ustjava.CurrentAccount;
import com.training.ustjava.FDAccount;
import com.training.ustjava.LoanAccount;
import com.training.ustjava.SBAccount;

@Controller
public class SBAccountController {

	@Autowired
	private SBAccountService service;

	/**
	 * To show all the SBAccount objects
	 */


	@RequestMapping("/showSb")

	public String showSBAccount(Model model) {

		SBAccount ca = new SBAccount();
		model.addAttribute("key", ca);
		return "addSb";

	}

	/**
	 * To add a SBAccount objects and display the  details of each SBAccount.
	 */

	@RequestMapping("/addsbaccount")
	public String addSbAccountObject(@ModelAttribute("sbAccount") SBAccount ca1) {


		service.addSBAccount(ca1);
		return "redirect:/fd";

	}

	/**
	 * Method to update the details of a particular account holder
	 */

	@RequestMapping("/updateSbAccount")
	public String updateSB(@ModelAttribute("sbAccount") SBAccount la) {

		service.updateLoanAccount(la);
		return "redirect:/sb";
	}


	@RequestMapping("/sb")

	/**
	 * To retrieve all SBAccount objects and display the  details of each SBAccount
	 */

	public String getAllSbAccount(Model model){

		System.out.println("Inside controller getAllSbAccount");
		List<SBAccount> sb = service.getAllSBAccountObjects();
		model.addAttribute("key",sb );
		return "sbAccountList";

	}

	/**
	 * To retrieve and display the SBAccount objects of a specific Account holder
	 */

	@RequestMapping("/specificsb")
	public String getSpecificSBAccount(@RequestParam("id") String id, Model model){

		SBAccount ca= service.getSBAccountByAccountno(Integer.parseInt(id));
		model.addAttribute("key1",ca );
		return "viewSbAccount";

	}

	/**
	 * To delete an account using accountno and to display the rest of SBAccount 
	 */

	@RequestMapping("/deletesb")
	public String deleteSpecificSbAccount(@RequestParam("id") String id, Model model){

		service.deleteSBAccountObject(Integer.parseInt(id));
		return "redirect:sb ";

	}

	/**
	 * To sort accounts using holder name and to display the details 
	 */

	@RequestMapping("/sortSbAccountByName")

	public String getAllSBAccountsSortByName(Model model){

		List<SBAccount> ca = service.getAllSBAccountObjectsSortByName();
		model.addAttribute("sbAccount",ca );
		return "redirect:/sb";

	}

	/**
	 * To sort accounts using accountno and to display the details 
	 */

	@RequestMapping("/sortSbAccountByAmount") 
	public String  getAllSBAccountsSortByAccountNo(Model model){

		List<SBAccount> ca = service.getAllSBAccountObjectsSortByBalance();
		model.addAttribute("sbAccount",ca );
		return "redirect:/sb";

	}
}
