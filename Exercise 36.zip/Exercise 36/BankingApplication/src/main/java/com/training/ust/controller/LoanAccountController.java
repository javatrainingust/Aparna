/**
 * 
 * LoanAccountController
 * 
 * Controller class for LoanAccountDAOImpl
 * 
 * 15-10-2020
 */

package com.training.ust.controller;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.training.ust.service.LoanAccountService;
import com.training.ustjava.CurrentAccount;
import com.training.ustjava.FDAccount;
import com.training.ustjava.LoanAccount;

@Controller
public class LoanAccountController {

	@Autowired
	private LoanAccountService service;

	/**
	 * To show all the LoanAccount objects 
	 */

	@RequestMapping("/showLoan")

	public String showLoanAccount(Model model) {

		LoanAccount ca = new LoanAccount();
		model.addAttribute("key", ca);
		return "addLoan";

	}

	/**
	 * To add a LoanAccount objects and display the  details of each LoanAccount.
	 */


	@RequestMapping("/addloanAccount")
	public String addLoanAccountObject(@ModelAttribute("loanAccount") LoanAccount ca1) {

		service.addLoanAccount(ca1);
		return "redirect:/loan";


	}
	/**
	 * Method to update the details of a particular account holder using account no
	 */

	@RequestMapping("/updateLoanAccount")
	public String updateLoan(@ModelAttribute("loanAccount") LoanAccount la) {

		service.updateLoanAccount(la);

		return "redirect:/loan";
	}


	@RequestMapping("/loan")
	/**
	 * Method to retrieve all LoanAccount objects and display the details of each LoanAccount 
	 */

	public String getAllFdAccount(Model model){

		System.out.println("Inside controller getAllFdAccount");
		List<LoanAccount> la = service.getAllLoanAccountObjects();

		model.addAttribute("key",la );


		return "loanAccountList";

	}

	/**
	 * To retrieve and display the LoanAccount objects of a specific Account holder
	 */

	@RequestMapping("/specificloan")
	public String getSpecificLoanAccount(@RequestParam("id") String id, Model model){

		LoanAccount ca= service.getLoanAccountByAccountno(Integer.parseInt(id));
		model.addAttribute("key1",ca );
		return "viewLoanAccount";

	}

	/**
	 * To delete an account using accountno and to display the rest of LoanAccount 
	 */

	@RequestMapping("/deleteloan")
	public String deleteSpecificLoanAccount(@RequestParam("id") String id, Model model){

		service.deleteCurrentAccountObject(Integer.parseInt(id));
		return "redirect:loan ";

	}

	/**
	 * To sort accounts using holder name and to display the details 
	 */

	@RequestMapping("/sortLoanAccountByName")

	public String getAllLoanAccountsSortByName(Model model){

		List<LoanAccount> ca = service.getAllLoanAccountObjectsSortByName();
		model.addAttribute("loanAccount",ca );
		return "redirect:/loan";

	}

	/**
	 * To sort accounts using accountno and to display the details 
	 */

	@RequestMapping("/sortLoanAccountByAmount") 
	public String  getAllLoanAccountsSortByAmount(Model model){

		List<LoanAccount> ca = service.getAllLoanAccountObjectsSortByBalance();
		model.addAttribute("loanAccount",ca );
		return "redirect:/loan";

	}
}