package com.training.ustjava.codingstn;

public class A {
	 int a=100;
	 
	 public void display()
	 {
		 
		 System.out.println("a in A= " +a);
		
	 }
	 

}
