/**
 * 
 *SBAccount is the extended class of base class Account containing variables and constructors
 *
 *30-09-2020
 */
package com.training.ustjava;

import java.util.Comparator;



public class SBAccount extends Account implements Comparator<SBAccount>, Comparable<SBAccount> {

	public float balance;
	//Parameterized constructor
	public SBAccount(int accoutNo, String holderName, float balance) {
		super(accoutNo, holderName);
		this.balance = balance;
	}

	//non arg constructor
	public SBAccount() {
	}

	/**
	 * Methods for comparator and comparable
	 */
	
	public int compare(SBAccount o1, SBAccount o2) {
		// TODO Auto-generated method stub
		return (int) (o1.balance-o2.balance);
	}


	
	public int compareTo(SBAccount o) {
		// TODO Auto-generated method stub
		return this.holderName.compareTo(o.getHolderName());
	}

	/*
	 * public float withdrawMoney(float amountWithdrawn) { balance=balance-
	 * amountWithdrawn; return balance;
	 * 
	 * }
	 */

	/**withdraw money method to withdraw money from SB account*/
	public float withdrawMoney(float amountToWithdraw) throws InsufficientBalanceException {

		if(amountToWithdraw>balance) {

			throw new InsufficientBalanceException(amountToWithdraw);
		}
		else {
			this.balance=balance-amountToWithdraw;
			return balance;
		}
	}
}




/*//float duration=1;
	//InterestCalculator ic= new InterestCalculator();

	public float getbalance() {
		return balance;
	}





  public void calculateInterest(float amount,ICalculator calculator){

  float sbinterest=calculator.interestCalculation( amount,duration);
  System.out.println(sbinterest); }




  } public void CalculateInterest() { this.ic.SavingsAccountInterest(30000, 1);
  }
 */


