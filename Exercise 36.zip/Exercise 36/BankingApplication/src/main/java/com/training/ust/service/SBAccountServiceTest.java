/***
 * SBAccountServiceTest
 * 
 * This is test class for SBAccountService
 * 
 * 07-10-2020
 *//*
	 * package com.training.ust.service;
	 * 
	 * import static org.junit.jupiter.api.Assertions.*;
	 * 
	 * import java.util.List;
	 * 
	 * import org.junit.jupiter.api.Test;
	 * 
	 * import com.training.ustjava.LoanAccount; import
	 * com.training.ustjava.SBAccount;
	 * 
	 * class SBAccountServiceTest {
	 * 
	 * for getting all accounts sorted by names
	 * 
	 * 
	 * @Test public void testSortedByNames() { String expectedValue ="Anna";
	 * SBAccountService sbAccountService=new SBAccountService(); List<SBAccount>
	 * sbAccountServiceList=sbAccountService.getAllSBAccountObjectsSortByName();
	 * String actualValue= sbAccountServiceList.get(0).getholdernamee();
	 * assertEquals(expectedValue,actualValue); } for getting all accounts sorted by
	 * balance
	 * 
	 * 
	 * @Test public void testSortedByBalance() { float expectedValue =2000;
	 * SBAccountService sbAccountService=new SBAccountService(); List<SBAccount>
	 * sbAccountServiceList=sbAccountService.getAllSBAccountObjectsSortByBalance();
	 * float actualValue=sbAccountServiceList.get(0).balance;
	 * assertEquals(expectedValue,actualValue,0.0f); }
	 * 
	 * 
	 * @Test public void testAdd() { SBAccount sbAccount = new SBAccount(1000,
	 * "Aparna", 20000); SBAccountService sbAccountService = new SBAccountService();
	 * sbAccountService.addSBAccount(sbAccount); assertEquals(1,
	 * sbAccountService.getAllSBAccountObjects().size()); }
	 * 
	 * @Test public void testUpdate() { SBAccount sbAccount1 = new SBAccount(1000,
	 * "Aparna", 2000); SBAccount sbAccount2 = new SBAccount(1000, "Appu", 30000);
	 * SBAccountService sbAccountService = new SBAccountService();
	 * sbAccountService.addSBAccount(sbAccount1);
	 * sbAccountService.addSBAccount(sbAccount2);
	 * 
	 * sbAccountService.updateLoanAccount(sbAccount2); assertEquals(1,
	 * sbAccountService.getAllSBAccountObjects().size()); }
	 * 
	 * 
	 * }
	 */