package com.training.ustjava;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

public class SBAccountTest {

	@Test
	public void test() {
		float expectedValue= 40000;
		SBAccount ca= new SBAccount();
		float actualValue=ca.withdrawMoney(60000);
		assertEquals(expectedValue,actualValue);
	}

}
