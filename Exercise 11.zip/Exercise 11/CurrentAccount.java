package com.training.ustjava;

public class CurrentAccount extends Account {

	float OverDraftLimit;
	public String CheckOverDraft(int Balance)
	{
		String str;
		if(Balance>=50000)
			str="Overdraft limit is 25000 as balance above 50000";

		else if(Balance >25000 && Balance <50000)
			str="Overdraft limit is 15000 as balance between 25k and 50k";

		else
			str="Overdraft limit is 5000 as balance is below 25k";
		return str;
	}

}
