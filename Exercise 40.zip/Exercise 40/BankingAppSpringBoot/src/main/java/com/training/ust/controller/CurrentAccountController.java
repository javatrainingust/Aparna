/**
 * CurrentAccountController
 * 
 * Controller class
 * 
 * 15-10-2020
 */


package com.training.ust.controller;

import org.springframework.stereotype.Controller;
import com.training.ust.service.CurrentAccountService;
import com.training.ustjava.CurrentAccount;
import com.training.ustjava.FDAccount;

import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;

@Controller
public class CurrentAccountController {

	@Autowired
	private CurrentAccountService service;

	/**
	 * To show all the CurrentAccount objects 
	 */

	@GetMapping("/showCurrent")

	public String showCurrentAccount(Model model) {

		CurrentAccount ca = new CurrentAccount();
		model.addAttribute("key", ca);
		return "addCurrent";
	}

	/**
	 * To add a CurrentAccount objects and display the  details of each CurrentAccount.
	 */

	@PostMapping("/addcurrentaccount")
	public String addCurrentAccountObject(@ModelAttribute("currentAccount") CurrentAccount ca1) {

		service.addCurrentAccount(ca1);
		System.out.println(ca1.getHolderName());
		return "redirect:/current";

	}

	/**
	 * Method to update the details of a particular Current account holder
	 */

	@PutMapping("/updateCurrentAccount")
	public String updateCurrent(@ModelAttribute("CurrentAccount") CurrentAccount la) {

		service.updateCurrentAccount(la);
		return "redirect:/current";
	}


	/**
	 * To retrieve all CurrentAccount objects and display the  details of each CurrentAccount.
	 */

	@GetMapping("/current")
	public String getAllCurrentAccount(Model model){

		System.out.println("Inside controller getAllCurrentAccount");
		List<CurrentAccount> ca = service.getAllCurrentAccountObjects();
		model.addAttribute("key",ca );
		return "currentAccountList";

	}


	/**
	 * To retrieve and display the CurrentAccount objects of a specific Account holder
	 */

	@GetMapping("/specificcurrent")
	public String getSpecificCurrentAccount(@RequestParam("id") String id, Model model){

		CurrentAccount ca= service.getCurrentAccountByAccountno(Integer.parseInt(id));
		model.addAttribute("key1",ca );
		return "viewcurrentAccount";

	}

	/**
	 * To delete an account using accountno and to display the rest of CurrentAccount 
	 */

	@DeleteMapping("/deletecurrent")
	public String deleteSpecificCurrentAccount(@RequestParam("id") String id, Model model){

		service.deleteCurrentAccountObject(Integer.parseInt(id));
		return "redirect:current ";

	}

	/**
	 * To sort accounts using holder name and to display the details 
	 */

	@GetMapping("/sortCurrentAccountByName")

	public String getAllCurrentAccountsSortByName(Model model){

		System.out.println("Inside controller getAllAccountsSortByName");
		List<CurrentAccount> ca = service.getAllCurrentAccountObjectsSortByName();
		model.addAttribute("currentAccount",ca );
		return "redirect:/current";

	}

	/**
	 * To sort accounts using accountno and to display the details 
	 */

	@GetMapping("/sortCurrentAccountByAccountNo") 
	public String  getAllCurrentAccountsSortByAmount(Model model){

		List<CurrentAccount> ca = service.getAllFDAccountObjectsSortByOverDraftAmount();
		model.addAttribute("currentAccount",ca );
		return "redirect:/current";

	}


}

