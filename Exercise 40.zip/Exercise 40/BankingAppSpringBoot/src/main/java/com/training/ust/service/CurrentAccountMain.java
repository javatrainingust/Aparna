package com.training.ust.service;
/**
 * 
 *This is the main class for Current Account
 * 
 *06-10-2020
 */


public class CurrentAccountMain {

	public static void main(String[] args) {
		CurrentAccountService caservice= new CurrentAccountService();

		caservice.getAllCurrentAccountObjects();
		System.out.println("-----------------------------------");
		caservice.getCurrentAccountByAccountno(1004);
		System.out.println("-----------------------------------");
		caservice.deleteCurrentAccountObject(1002);
		System.out.println("-----------------------------------");
		caservice.getAllCurrentAccountObjects();

	}

}