/**
 * BankingMapperLoanAccount
 * 
 * Mapper class that implements RowMapper Interface
 * 
 *  23-10-2020
 */
package com.ust.java.dataaccess;

import java.sql.ResultSet;
import java.sql.SQLException;
import org.springframework.jdbc.core.RowMapper;
import com.training.ustjava.LoanAccount;

public class BankingMapperLoanAccount implements RowMapper<LoanAccount> {

	/**
	 * Method is used to map loanAccount records to loanAccount object 
	 */

	public LoanAccount mapRow(ResultSet rs, int rowNum) throws SQLException{

		LoanAccount la =  new LoanAccount();
		la.setAccountNo(rs.getInt("Number"));
		la.setHolderName(rs.getString("Name"));
		return la;
	}

}


