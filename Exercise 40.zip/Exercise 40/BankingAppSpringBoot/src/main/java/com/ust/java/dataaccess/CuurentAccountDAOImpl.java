/**
 * 
 *CurrentAccountDAOImpl is the implementation class forCurrentAccountDAO
 * 
 *06-10-2020
 */

package com.ust.java.dataaccess;

import org.springframework.stereotype.Repository;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

import com.training.ustjava.CurrentAccount;

@Repository
public class CuurentAccountDAOImpl implements CurrentAccountDAO {

	//Creating a list and inserting the values into it
	List <CurrentAccount> CurrentAccountList;
	Set<CurrentAccount> CurrentAccountSet;

	public CuurentAccountDAOImpl()
	{
		CurrentAccountList= new ArrayList<CurrentAccount>();
		CurrentAccountSet= new HashSet<CurrentAccount>();


		CurrentAccount ca1= new CurrentAccount(1000, "Aparna", 20000); CurrentAccount
		ca2= new CurrentAccount(1001, "Anu", 50000); CurrentAccount ca3= new
		CurrentAccount(1002, "Ravi", 40000); CurrentAccount ca4= new
		CurrentAccount(1003, "Karthi",80000); CurrentAccount ca5= new
		CurrentAccount(1004, "Anju", 4000);

		CurrentAccountList.add(ca1); CurrentAccountList.add(ca2);
		CurrentAccountList.add(ca3); CurrentAccountList.add(ca4);
		CurrentAccountList.add(ca5);


	}
	/**
	 * Method to get all objects printed
	 */


	public List<CurrentAccount> getAllCurrentAccountObjects() {
		return CurrentAccountList;
	}
	/**
	 * Method to retrive details of given accountno
	 */

	public CurrentAccount getCurrentAccountByAccountno(int accountNo) {
		CurrentAccount currentaccount=null;

		
		  Iterator<CurrentAccount> iterator= CurrentAccountList.iterator();
		  while(iterator.hasNext()) { CurrentAccount ca= iterator.next();
		  if(ca.getAccountNo()==accountNo) currentaccount=ca; }
		 
		return currentaccount;
	}
	/**
	 * Method to delete an entry for given accountno
	 */

	public void deleteCurrentAccountObject(int accountNo) {
		for( int i=0; i<CurrentAccountList.size();i++)
		{
			CurrentAccount ca= CurrentAccountList.get(i);
			if(ca.getAccountNo()==accountNo)
			{
				CurrentAccountList.remove(i);
			}
		}

	}

	/**
	 * 
	 * Method to add a new entry
	 */

	public boolean addCurrentAccountObject(CurrentAccount ca)
	{

		boolean isAdded= CurrentAccountSet.add(ca);
		if(isAdded)
		{
			CurrentAccountList.add(ca);
		}
		return isAdded;
	}
	/**
	 * Method to update an entry

	 */

	public void updateCurrentAccountObject(CurrentAccount currentAccount)
	{
		Iterator iterator= CurrentAccountList.iterator();

		while(iterator.hasNext())
		{
			CurrentAccount ca= (CurrentAccount)iterator.next();
			if(ca.getAccountNo()==currentAccount.getAccountNo())
			{
				ca.setHolderName(currentAccount.getHolderName());
				ca.setAccountNo(currentAccount.getAccountNo());
			}

		}

	}

}
