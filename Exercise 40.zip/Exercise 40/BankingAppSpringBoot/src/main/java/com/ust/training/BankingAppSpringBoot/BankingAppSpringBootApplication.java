package com.ust.training.BankingAppSpringBoot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BankingAppSpringBootApplication {

	public static void main(String[] args) {
		SpringApplication.run(BankingAppSpringBootApplication.class, args);
	}

}
