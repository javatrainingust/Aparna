/**
 * 
 * LoanAccountController
 * 
 * Controller class for LoanAccountDAOimpl
 * 
 * 15-10-2020
 */

package com.training.ust.controller;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.training.ust.service.LoanAccountService;
import com.training.ustjava.CurrentAccount;
import com.training.ustjava.LoanAccount;

@Controller
public class LoanAccountController {

	@Autowired
	private LoanAccountService service;


	@RequestMapping("/loan")
	/**
	 * Method to retrieve all LoanAccount objects and display the details of each LoanAccount LoanAccountController
	 */
	public String getAllFdAccount(Model model){

		System.out.println("Inside controller getAllFdAccount");
		List<LoanAccount> la = service.getAllLoanAccountObjects();

		model.addAttribute("key",la );


		return "loanAccountList";

	}
	
	/**
	 * To retrieve and display the LoanAccount objects of a specific Account holder
	 */
	
	@RequestMapping("/specificloan")
	public String getSpecificLoanAccount(@RequestParam("id") String id, Model model){
		
		LoanAccount ca= service.getLoanAccountByAccountno(Integer.parseInt(id));
		model.addAttribute("key1",ca );
		return "viewLoanAccount";

	}
	
	/**
	 * To delete an account using accountno and to display the rest of LoanAccount 
	 */
	
	@RequestMapping("/deleteloan")
	public String deleteSpecificLoanAccount(@RequestParam("id") String id, Model model){
		
		service.deleteCurrentAccountObject(Integer.parseInt(id));
		return "redirect:loan ";

	}
}