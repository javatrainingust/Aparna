/**
 * CurrentAccountController
 * 
 * Controller class
 * 
 * 15-10-2020
 */


package com.training.ust.controller;

import org.springframework.stereotype.Controller;
import com.training.ust.service.CurrentAccountService;
import com.training.ustjava.CurrentAccount;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;

@Controller
public class CurrentAccountController {

	@Autowired
	private CurrentAccountService service;

	/**
	 * To retrieve all CurrentAccount objects and display the  details of each FDAccount.
	 */
	
	@RequestMapping("/current")
	public String getAllCurrentAccount(Model model){

		System.out.println("Inside controller getAllCurrentAccount");
		List<CurrentAccount> ca = service.getAllCurrentAccountObjects();

		model.addAttribute("key",ca );
		return "currentAccountList";

	}
	

	/**
	 * To retrieve and display the CurrentAccount objects of a specific Account holder
	 */
	
	@RequestMapping("/specificcurrent")
	public String getSpecificCurrentAccount(@RequestParam("id") String id, Model model){
		
		CurrentAccount ca= service.getCurrentAccountByAccountno(Integer.parseInt(id));
		model.addAttribute("key1",ca );
		return "viewcurrentAccount";

	}
	
	/**
	 * To delete an account using accountno and to display the rest of CurrentAccount 
	 */
	
	@RequestMapping("/deletecurrent")
	public String deleteSpecificCurrentAccount(@RequestParam("id") String id, Model model){
		
		service.deleteCurrentAccountObject(Integer.parseInt(id));
		return "redirect:current ";

	}

}





