/**
 *Signup
 *
 *Signup class is the model class for Signing up.
 *
 * 15-10-2020
 * */

package com.ust.java.spring;

public class SignUp {

	String userName;
	String userId;
	String password;
	String confirmPassword;

	/**
	 * Getter and setter methods for all the variables
	 */


	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getConfirmPassword() {
		return confirmPassword;
	}
	public void setConfirmPassword(String confirmPassword) {
		this.confirmPassword = confirmPassword;
	}

}
