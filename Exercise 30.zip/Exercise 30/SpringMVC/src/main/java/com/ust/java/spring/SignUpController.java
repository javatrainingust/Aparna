/**
 * SignUpController
 * 
 * SignUpController is the controller class
 * 
 * 15/10/2020
 * */

package com.ust.java.spring;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class SignUpController {
	/**
	 *Method  to show form
	 */
	@RequestMapping("/showForm")
	public String showForm(Model theModel) {

		// create a SignUp object
		SignUp theSignUp = new SignUp();

		// add SignUp object to the model
		theModel.addAttribute("signup", theSignUp);
		return "signup";
	}

	/**
	 * This method will process the form data and returns to a jsp page using model attribute. 
	 * */

	@RequestMapping("/processForm")
	public String processForm(@ModelAttribute("signup") SignUp theSignup)
	{
		System.out.println("Details :" +theSignup.userName +theSignup.userId);
		return "confirmSignUp";

	}

}
