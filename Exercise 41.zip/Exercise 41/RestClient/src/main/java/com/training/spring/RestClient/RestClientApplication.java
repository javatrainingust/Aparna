/**
 * RestclientApplication
 * 
 * Rest client for banking application
 * 
 * 28/10/2020
 */

package com.training.spring.RestClient;

import java.util.HashMap;
import java.util.Map;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;

import com.training.spring.model.SBAccount;


/**
 * Method to implement rest client
 *
 */
@SpringBootApplication
public class RestClientApplication {

	public static void main(String[] args) {
		SpringApplication.run(RestClientApplication.class, args);


		//getResource();
		//postResource();
		//putResource();
		deleteResource();
		getAllResources();
	}
	
	/**
	 * Method to get and print a specific  account
	 */
	public static void  getResource() {

		RestTemplate restTemplate = new RestTemplate();

		final String uri = "http://localhost:8000/banking/sbaccounts/{id}";

		Map<String, Integer> params = new HashMap<String, Integer>();
		params.put("id", 1000);

		SBAccount result = restTemplate.getForObject(uri, SBAccount.class, params);

		System.out.println("Account Number: "+result.getAccountNo());
		System.out.println("Name: "+result.getHolderName());
		System.out.println("Balance: "+result.balance);


	}

	/**
	 * Method to get and print a all  account
	 */
	public static void getAllResources() {

		System.out.println("Inside getAllResources() method");
		RestTemplate restTemplate = new RestTemplate();
		final String uri = "http://localhost:8000/banking/sbaccounts";

		ResponseEntity<SBAccount[]> response  = restTemplate.getForEntity(uri, SBAccount[].class);
		SBAccount[] accounts = response.getBody();

		for(int i=0; i<accounts.length;i++) {

			SBAccount result= (SBAccount)accounts[i];	    
			System.out.println("Account Number: "+result.getAccountNo());
			System.out.println("Name: "+result.getHolderName());
			System.out.println("Balance: "+result.balance);

		}

	}
	/**
	 * Method to add one new account
	 */
	public static void postResource() {

		RestTemplate restTemplate = new RestTemplate();

		final String uri = "http://localhost:8000/banking/sbaccounts";

		SBAccount pe = new SBAccount(2000, "Alka", 2300f);

		SBAccount result = restTemplate.postForObject( uri, pe, SBAccount.class);


	}

	/**
	 * Method to update one account
	 */
	public static void putResource() {

		RestTemplate restTemplate = new RestTemplate();

		final String uri = "http://localhost:8000/banking/sbaccounts/{id}";

		Map<String, Integer> params = new HashMap<String, Integer>();
		params.put("id", 2000);

		SBAccount updatedEmployee = new SBAccount(1001, "Alka Menon", 2300f);

		restTemplate.put(uri, updatedEmployee, params);

	}
	/**
	 * Method to delete an account
	 */
	public static void deleteResource() {

		RestTemplate restTemplate = new RestTemplate();

		final String uri = "http://localhost:8000/banking/sbaccounts/{id}";

		Map<String, Integer> params = new HashMap<String, Integer>();
		params.put("id", 2000);

		restTemplate.delete(uri, params);
	}


}
