/**
 * 
 * Account
 * 
 *This is the base class for FDAccount,SBAccount,LoanAccount and CurrentAccount
 *
 *30-09-2020
 */

package com.training.ustjava;

public class Account {

	//Non argument constructor
	public Account() {
	}

	//Parameterized constructor
	public Account(int accountNo, String holderName) {

		//System.out.println("Inside Base Class arg constructor " +accountNo +" "+holderName); 
		this.accountNo=accountNo; 
		this.holderName=holderName; 
	}
	/**
	 * Getter and Setter methods for the variables accountNo and hilderName
	 */

	private int accountNo;
	protected String holderName;

	/*
	 * public int getaccountnumber() { return accountNo; } public void
	 * setaccountnumber(int accountnumber) { this.accountNo = accountnumber; }
	 * public String getholdernamee() { return holderName; } public void
	 * setholdername(String holdername) { this.holderName = holdername; }
	 */

	/**
	 * Hashcode and equals method is implemented to add new entry to the account and duplication is not allowded
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + accountNo;
		return result;
	}

	public int getAccountNo() {
		return accountNo;
	}

	public void setAccountNo(int accountNo) {
		this.accountNo = accountNo;
	}

	public String getHolderName() {
		return holderName;
	}

	public void setHolderName(String holderName) {
		this.holderName = holderName;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Account other = (Account) obj;
		if (accountNo != other.accountNo)
			return false;
		return true;
	}


}