/*package com.training.account;

import com.training.ustjava.*;

public class Withdrawal {

	public static void main(String args[]){
		
		/*IntrestCalculation calculator=new IntrestCalculation
				
		Account account =new Account();
		account.calculateInterest(100, calculator);

		SBAccount sb= new SBAccount();
		//sb.withdrawMoney(5000);
		sb.calculateInterest(50000,1, "Aparna");

		FDAccount fd= new FDAccount();
		ICalculator calculator = new InterestCalculator();
		//fd.updateautoRenewal();
		fd.CalculateInterest(30000,calculator);
		fd.CalculateInterest(30000, 1);
		
		/*CurrentAccount ca= new CurrentAccount();
		ca.CheckOverDraft();
		
		LoanAccount la= new LoanAccount();
		la.CalculateEmi(200000);
	

	}

} 

*/
