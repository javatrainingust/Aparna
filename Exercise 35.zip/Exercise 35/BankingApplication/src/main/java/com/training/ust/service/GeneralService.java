package com.training.ust.service;

import com.training.ustjava.FDAccount;
import com.training.ustjava.InterestCalculator;

public class GeneralService {

	public static void main(String[] args) {

		FDAccount fd=  new FDAccount(1234, "Aparna", 10, 20);
		
		//fd.setaccountnumber(1234);
		//fd.setholdername("Aparna");
		
		InterestCalculator ic= new InterestCalculator();
		ic.FixedAccountInterest(10000, 2);
	}
}
		
	
		
		
		
		/*fd.CalculateInterestFD(1000,2);

		SBAccount sb= new SBAccount();
		sb.withdrawMoney(2000); 
		
		Account account3 =new Account();
		SBAccount sbAccount=(SBAccount)account3;
		sbAccount.withdrawMoney(2); 

		Account[] a= {new Account(), fd, sb};

		InterestCalculator calculator = new InterestCalculator();

		for(Account account :a){

			account.calculateInterest(1000,calculator);

			if(account instanceof FDAccount){

				FDAccount fda = (FDAccount)account;

				fda.CalculateInterestFD(1000,1); 
			}
		}
	}
}*/
