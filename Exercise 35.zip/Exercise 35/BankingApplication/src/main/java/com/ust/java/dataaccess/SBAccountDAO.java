package com.ust.java.dataaccess;

/**
 * 
 *SBAccountDAO is the interface with the specified 3 methods
 *
 *06-10-2020
 */

import java.util.List;

import com.training.ustjava.SBAccount;

public interface SBAccountDAO {
	
	public List<SBAccount> getAllSBAccountObjects();
	public SBAccount getSBAccountByAccountno(int accountNo);
	public void deleteSBAccountObject(int accountNo);
	public void updateSBAccountObject(SBAccount sbccount);
	public boolean addSBAccountObject(SBAccount fd);

}
