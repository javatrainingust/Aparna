
/**
 * 
 *FDAccountDAOImpl is the implementation class for FDAccountDAO
 * 
 *06-10-2020
 */

package com.ust.java.dataaccess;

import java.util.*;
import org.springframework.stereotype.Repository;
import com.training.ustjava.FDAccount;

@Repository
public class FDAccountDAOImpl implements FDAccountDAO {

	List<FDAccount> FDAccountList;
	Set<FDAccount> fdAccountSet;

	//Creating a list and inserting the values into it
	public FDAccountDAOImpl() {

		FDAccountList= new ArrayList<FDAccount>();
		fdAccountSet= new HashSet<FDAccount>();

		FDAccount fd1= new FDAccount(1000, "Aparna",2000,3); 
		FDAccount fd2= new FDAccount(1001, "Arun", 4000,1); 
		FDAccount fd3= new FDAccount(1002, "Anna", 6000,5); 
		FDAccount fd4= new FDAccount(1003, "Minu", 6000,8); 
		FDAccount fd5= new FDAccount(1004, "Delna", 8000,2);

		FDAccountList.add(fd1); FDAccountList.add(fd2); FDAccountList.add(fd3);
		FDAccountList.add(fd4); FDAccountList.add(fd5);

	}

	/**
	 * Method to print all enteries
	 */



	public List<FDAccount> getAllFDAccountObjects() {
		return FDAccountList;
	}

	/**
	 * Method to retrieve one entry for given account no
	 */


	public FDAccount getFDAccountByAccountno(int AccountNo) {
		FDAccount fdAccount=null;

		Iterator<FDAccount> iterator=FDAccountList.iterator();
		while(iterator.hasNext())
		{
			FDAccount fd=iterator.next();
			if(fd.getAccountNo()==AccountNo)
				fdAccount=fd;

		}
		return fdAccount;
	}

	/**
	 * Method to delete an entry
	 */


	public void deleteFDAccountObject(int AccountNo) {

		for(int i=0; i< FDAccountList.size(); i++){
			FDAccount fd =(FDAccount)FDAccountList.get(i);
			if(fd.getAccountNo()==AccountNo)
			{
				FDAccountList.remove(i);
			}

		}
	}

	/**
	 * 
	 * Method to add a new entry
	 */

	public boolean addFDAccountObject(FDAccount fd)
	{

		boolean isAdded= fdAccountSet.add(fd);
		if(isAdded)
		{
			FDAccountList.add(fd);
		}
		return isAdded;
	}
	/**
	 * Method to update an entry

	 */

	public void updateFDAccountObject(FDAccount fdAccount)
	{
		Iterator iterator= FDAccountList.iterator();

		while(iterator.hasNext())
		{
			FDAccount fd= (FDAccount)iterator.next();
			if(fd.getAccountNo()==fdAccount.getAccountNo())
			{
				fd.setHolderName(fdAccount.getHolderName());
				fd.setAccountNo(fdAccount.getAccountNo());
			}

		}

	}

}
