/**
 *FDAccountService
 *
 *This is the service class for FDAccount
 *
 *06/10/2020
 *
 */

package com.training.ust.service;

import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.training.ustjava.FDAccount;
import com.ust.java.dataaccess.FDAccountDAO;
import com.ust.java.dataaccess.FDAccountDAOImpl;

@Service
public class FDAccountService {

	@Autowired
	FDAccountDAO daoImpl;

	public FDAccountService()
	{
		daoImpl= new FDAccountDAOImpl();
	}
	/**
	 * Method to print all objects in FdAccount
	 */
	public List<FDAccount> getAllFDaccountObjects() {
		List<FDAccount> FDAccountList= daoImpl.getAllFDAccountObjects();
		/*
		 * Iterator<FDAccount> iterator = FDAccountList.iterator();
		 * 
		 * while(iterator.hasNext()){
		 * 
		 * FDAccount fd = iterator.next();
		 * 
		 * System.out.println("Account Number: "+fd.getaccountnumber());
		 * System.out.println("Holder name: "+fd.getholdernamee());
		 * System.out.println("Amount: "+fd.amount);
		 * System.out.println("Duration: "+fd.duration); }
		 */

		return FDAccountList;
	}


	/**
	 * Method to print the details of the customer for given account no
	 */
	public FDAccount getFDAccountByAccountno(int accountnumber) {
		FDAccount fd = daoImpl.getFDAccountByAccountno(accountnumber);
		System.out.println("Account Number: "+fd.getAccountNo());
		System.out.println("Holder name: "+fd.getHolderName());
		System.out.println("Amount: "+fd.amount);
		System.out.println("Duration: "+fd.duration);
		return fd;
	}

	/**
	 * Method to delete the entry for the customer for given accountno
	 */

	public void deleteFDAccountObject(int accountnumber) {
		daoImpl.deleteFDAccountObject(accountnumber);
	}

	/**
	 * Method to sort the details of customer by name
	 */

	public List<FDAccount> getAllFDAccountObjectsSortByName()
	{
		List<FDAccount> fdAccountList= daoImpl.getAllFDAccountObjects();
		Collections.sort(fdAccountList);

		
		/**
		 * Stream<FDAccount> stream= fdAccountList.stream(); Stream<FDAccount> result=
		 * stream.sorted(); List sorted=result.collect(Collectors.toList());
		 * 
		 * 
		 * 
		 * Iterator<FDAccount> iterator= sorted.iterator(); while(iterator.hasNext()) {
		 * FDAccount fd = iterator.next();
		 * 
		 * System.out.println("Account Number: "+fd.getAccountNo());
		 * System.out.println("Holder name: "+fd.getHolderName());
		 * System.out.println("Amount: "+fd.amount); System.out.println("Duration:
		 * "+fd.duration);
		 * 
		 * }
		 */

		return fdAccountList;

	}

	/**
	 * Method to sort the details of customer by amount
	 */

	public List<FDAccount> getAllFDAccountObjectsSortByAmount()
	{
		List<FDAccount> fdAccountList= daoImpl.getAllFDAccountObjects();
		//Collections.sort(fdAccountList, new FDAccount());

		Stream<FDAccount> stream= fdAccountList.stream();
		Stream<FDAccount> result= stream.sorted(new FDAccount());
		List sorted=result.collect(Collectors.toList());

		Iterator<FDAccount> iterator= sorted.iterator();
		while(iterator.hasNext())
		{
			FDAccount fd = iterator.next();

			System.out.println("Account Number: "+fd.getAccountNo());
			System.out.println("Holder name: "+fd.getHolderName());
			System.out.println("Amount: "+fd.amount);
			System.out.println("Duration: "+fd.duration);

		}

		return fdAccountList;

	}

	/**
	 * Method to add a new entry
	 */

	public void addFDAccount(FDAccount fdAccount)
	{
		boolean isAdded=daoImpl.addFDAccountObject(fdAccount);

		if(!isAdded) {
			System.out.println("Already exist");
		}
		else
			System.out.println("Added");
	}
	/**
	 * Method to update an entry
	 */

	public void updateFDAccount(FDAccount fdAccount)
	{
		daoImpl.updateFDAccountObject(fdAccount);
	}
}
