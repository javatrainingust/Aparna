/**
 * 
/*Current Account is the extended class of base class Account containing variables and constructors
 *
 *30-09-2020
 */

package com.training.ustjava;

import java.util.Comparator;

public class CurrentAccount extends Account implements Comparable<CurrentAccount>, Comparator<CurrentAccount> {

	public float OverDraftLimit;

public CurrentAccount() {
		
	}

	//Parameterized Constructor
	public CurrentAccount(int accountNo, String holderName, float overDraftLimit) {
		super(accountNo,holderName);
		OverDraftLimit = overDraftLimit;
	}

	public int compare(CurrentAccount o1, CurrentAccount o2) {
		// TODO Auto-generated method stub
		return (int) (o1.OverDraftLimit-o2.OverDraftLimit);
	}

	public int compareTo(CurrentAccount o) {
		// TODO Auto-generated method stub
		return this.holderName.compareTo(o.getHolderName());
	}
}

/*
 * public String CheckOverDraft(int Balance) { String str; if(Balance>=50000)
 * str="Overdraft limit is 25000 as balance above 50000";
 * 
 * else if(Balance >25000 && Balance <50000)
 * str="Overdraft limit is 15000 as balance between 25k and 50k";
 * 
 * else str="Overdraft limit is 5000 as balance is below 25k"; return str; }
 */