package com.training.ustjava.codingstn;

/**
 * 
 *FdAccount 
 *
 *FdAccount is class containing parameterized constructor and also the method to check whether the account needs to be auto renewed
 *
 *30-09-2020
 */

public class FdAccount extends Account {	
	
	public int tenure=10;
	private float amount;
	private float duration;

	public FdAccount() {
		System.out.println("Inside FD, no argument Constructor");
	}

	public FdAccount(int accountNumber, String holderName,float amount, float duration) {
		super(1000, "Aparna");
		System.out.println("Inside FD, argument Constructor");
		this.amount=amount;
		this.duration=duration;
	}

		public void updateAutoRenewal()		/*Method checks if the account needs to be 
											  autorenewed if the tenure is greater than 5*/
		{
			boolean check = (tenure>5)?true:false;
			System.out.println("FD Account need auto renewal: " +check);

		}
}