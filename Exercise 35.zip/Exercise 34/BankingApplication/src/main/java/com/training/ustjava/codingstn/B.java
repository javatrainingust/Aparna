package com.training.ustjava.codingstn;

public class B extends A{
	
	private int a= 123;
	 
	 public void display()
	 
	 {
		 System.out.println("a in B= " +a);
	 }

}
