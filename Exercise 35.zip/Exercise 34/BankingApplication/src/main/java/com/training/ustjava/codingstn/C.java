package com.training.ustjava.codingstn;

public class C extends B{
	
	private int a= 543;
	 
	 public void display()
	 
	 {
		 System.out.println("a in C= " +a);
	 }

}
