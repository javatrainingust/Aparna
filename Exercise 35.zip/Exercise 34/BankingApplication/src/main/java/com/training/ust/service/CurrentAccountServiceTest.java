///***
// * CurrentAccountServiceTest 
// * 
// * This is test class for CurrentAccountService
// * 
// * 07-10-2020
// * */
//
//package com.training.ust.service;
//
//
//import java.util.List;
//import org.junit.jupiter.api.Test;
//import com.training.ustjava.CurrentAccount;
//
//class CurrentAccountServiceTest {
//
//	/* for getting all accounts sorted by names */
//
//	/*
//	 * @Test public void testSortedByNames() { String expectedValue ="Anju";
//	 * CurrentAccountService currentAccountService=new CurrentAccountService();
//	 * List<CurrentAccount> currentAccountServiceList=currentAccountService.
//	 * getAllCurrentAccountObjectsSortByName(); String actualValue=
//	 * currentAccountServiceList.get(0).getholdernamee();
//	 * assertEquals(expectedValue,actualValue); } for getting all accounts sorted by
//	 * balance
//	 * 
//	 * 
//	 * @Test public void testSortedByBalance1() { float expectedValue =4000;
//	 * CurrentAccountService currentAccountService=new CurrentAccountService();
//	 * List<CurrentAccount> currentAccountServiceList=currentAccountService.
//	 * getAllFDAccountObjectsSortByOverDraftAmount() ; float
//	 * actualValue=currentAccountServiceList.get(0).OverDraftLimit;
//	 * assertEquals(expectedValue,actualValue,0.0f); }
//	 */
//
//	@Test
//	public void testAdd() {
//		CurrentAccount currentAccount = new CurrentAccount(1000, "Aparna", 20000);
//		CurrentAccountService currentAccountService = new CurrentAccountService();
//		currentAccountService.addCurrentAccount(currentAccount);
//		assertEquals(1, currentAccountService.getAllCurrentAccountObjects().size());
//	}
//	
//	@Test
//	public void testUpdate() {
//		CurrentAccount currentAccount1 = new CurrentAccount(1000, "Aparna", 20000);
//		CurrentAccount currentAccount2 = new CurrentAccount(1000, "Appu", 30000);
//		CurrentAccountService currentAccountService = new CurrentAccountService();
//		currentAccountService.addCurrentAccount(currentAccount1);
//		currentAccountService.addCurrentAccount(currentAccount2);
//		
//		currentAccountService.updateCurrentAccount(currentAccount2);
//		assertEquals(1, currentAccountService.getAllCurrentAccountObjects().size());
//	}
//
//}
