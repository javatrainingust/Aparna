package com.training.ustjava;

public class InterestCalculator 
{


	public double FixedAccountInterest(float amount, float duration)
	{
		double rate =0.7;
		double interst= (amount*duration*rate)/100;
		return interst;
	}

	public double SavingsAccountInterest(float amount, float duration)
	{
		double rate =0.3;
		double interst= (amount*duration*rate)/100;
		return interst;
	}
}

/*
	public double CalculateInterest(float amount, float duration)
	{
		double rate =0.7;
		double interest= (amount*duration*rate)/100;
		return interest;
	}*/