/*
 * package com.ust.java.dataaccess;
 * 
 * import static org.junit.Assert.assertEquals; import static
 * org.junit.jupiter.api.Assertions.*;
 * 
 * import java.util.ArrayList; import java.util.List;
 * 
 * import org.junit.jupiter.api.Test;
 * 
 * import com.training.ustjava.CurrentAccount;
 * 
 * class CurrentAccountDAOImplTest { List<CurrentAccount> CurrentAccountList;
 * CurrentAccountDAO accountDAO;
 * 
 * public CurrentAccountDAOImplTest() { accountDAO = new
 * CuurentAccountDAOImpl(); }
 * 
 * @Test void getAllCurrentAccountObjectsTest() { int count =
 * accountDAO.getAllCurrentAccountObjects().size(); assertEquals(5,count); }
 * 
 * @Test void getCurrentAccountByAccountnoTest() { CurrentAccount account =
 * accountDAO.getCurrentAccountByAccountno(1000);
 * assertEquals("Aparna",account.getHolderName()); }
 * 
 * @Test void deleteCurrentAccountObjectTest() {
 * accountDAO.deleteCurrentAccountObject(1000); int count =
 * accountDAO.getAllCurrentAccountObjects().size(); assertEquals(4,count); }
 * 
 * }
 */
