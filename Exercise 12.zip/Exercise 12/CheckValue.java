package com.ust.java.lambda;

public interface CheckValue {
	
	public Boolean check( int n);

}
