package com.ust.java.lambda;

public interface Test {
	
	public int test( int n);

}
