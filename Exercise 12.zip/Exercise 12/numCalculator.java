package com.ust.java.lambda;

public interface numCalculator {
	
	public int getValue( int a, int b);

}
