package com.ust.java.lambda;

public interface DisplayResult {
	
	public void display(String s);

}
