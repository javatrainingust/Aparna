package com.ust.java.lambda;

public class Main {

	public static void main(String[] args) {

		CheckValue cv= (n)-> { 
			System.out.println(n>5);
			return (n>5);
		};
		cv.check(8);


		numCalculator nc= (a,b)->a+b;
		System.out.println("The sum of a and b is " +nc.getValue(3,4));
		
		DisplayResult dr =(s)->System.out.println("My name is " +s);
		dr.display("Aparna");


		Test t=(n)->++n;
		System.out.println("The increment for n is " +t.test(3));

	}

}