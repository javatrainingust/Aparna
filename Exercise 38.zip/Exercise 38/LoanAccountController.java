/**
 * 
 * LoanAccountController
 * 
 * Controller class for LoanAccountDAOImpl
 * 
 * 15-10-2020
 */

package com.training.ust.controller;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import com.training.ust.service.LoanAccountService;
import com.training.ustjava.LoanAccount;

//RestController annotation is used to create RESTful web services using Spring MVC
@RestController
public class LoanAccountController {

	//Autowired annotation is used to create the object for service class
	@Autowired
	private LoanAccountService service;

	/**
	 * Method to create a new Loan Account
	 */
	@RequestMapping(value = "/loanaccount", method = RequestMethod.POST)
	public LoanAccount addLoanAccount(@RequestBody LoanAccount sb) {

		service.addLoanAccount(sb);
		return sb;
	}

	/**
	 * Method to retrieve all Loan Accounts
	 */
	@RequestMapping(value = "/loanaccount", method = RequestMethod.GET)
	public List<LoanAccount> getAllLoanAccount() {

		//Getting all the details into the list
		List <LoanAccount> sbList= service.getAllLoanAccountObjects();
		return sbList;
	}

	/**
	 * Method to retrieve a specific Loan Account using account number
	 */
	@RequestMapping(value = "/loanaccount/{id}", method = RequestMethod.GET)
	public LoanAccount getSpecificLoanAccount(@PathVariable int id) {

		LoanAccount sb= service.getLoanAccountByAccountno(id);
		return sb;
	}

	/**
	 * Method to update a specific Loan Account using account number
	 */
	@RequestMapping(value = "/loanaccount/{id}", method = RequestMethod.PUT)
	public LoanAccount updateLoanAccount(@PathVariable int id, @RequestBody LoanAccount sb) {

		LoanAccount sbAccount= service.getLoanAccountByAccountno(id);
		
		//We need to update the details only if any field is changed
		if(sbAccount!=null)
		{
			service.updateLoanAccount(sb);
		}

		return sb;
	}

	/**
	 * Method to delete a specific Loan Account using account number
	 */
	@RequestMapping(value = "/loanaccount/{id}", method = RequestMethod.DELETE)
	public void deleteLoanAccount(@PathVariable int id) {

		service.deleteCurrentAccountObject(id);	
	}
}







/**
 * To show all the LoanAccount objects 
 *//*

	@RequestMapping("/showLoan")

	public String showLoanAccount(Model model) {

		LoanAccount ca = new LoanAccount();
		model.addAttribute("key", ca);
		return "addLoan";

	}

  *//**
  * To add a LoanAccount objects and display the  details of each LoanAccount.
  *//*


	@RequestMapping("/addloanAccount")
	public String addLoanAccountObject(@ModelAttribute("loanAccount") LoanAccount ca1) {

		service.addLoanAccount(ca1);
		return "redirect:/loan";


	}
   *//**
   * Method to update the details of a particular account holder using account no
   *//*

	@RequestMapping("/updateLoanAccount")
	public String updateLoan(@ModelAttribute("loanAccount") LoanAccount la) {

		service.updateLoanAccount(la);

		return "redirect:/loan";
	}


	@RequestMapping("/loan")
    *//**
    * Method to retrieve all LoanAccount objects and display the details of each LoanAccount 
    *//*

	public String getAllFdAccount(Model model){

		System.out.println("Inside controller getAllFdAccount");
		List<LoanAccount> la = service.getAllLoanAccountObjects();

		model.addAttribute("key",la );


		return "loanAccountList";

	}

     *//**
     * To retrieve and display the LoanAccount objects of a specific Account holder
     *//*

	@RequestMapping("/specificloan")
	public String getSpecificLoanAccount(@RequestParam("id") String id, Model model){

		LoanAccount ca= service.getLoanAccountByAccountno(Integer.parseInt(id));
		model.addAttribute("key1",ca );
		return "viewLoanAccount";

	}

      *//**
      * To delete an account using accountno and to display the rest of LoanAccount 
      *//*

	@RequestMapping("/deleteloan")
	public String deleteSpecificLoanAccount(@RequestParam("id") String id, Model model){

		service.deleteCurrentAccountObject(Integer.parseInt(id));
		return "redirect:loan ";

	}

       *//**
       * To sort accounts using holder name and to display the details 
       *//*

	@RequestMapping("/sortLoanAccountByName")

	public String getAllLoanAccountsSortByName(Model model){

		List<LoanAccount> ca = service.getAllLoanAccountObjectsSortByName();
		model.addAttribute("loanAccount",ca );
		return "redirect:/loan";

	}

        *//**
        * To sort accounts using accountno and to display the details 
        *//*

	@RequestMapping("/sortLoanAccountByAmount") 
	public String  getAllLoanAccountsSortByAmount(Model model){

		List<LoanAccount> ca = service.getAllLoanAccountObjectsSortByBalance();
		model.addAttribute("loanAccount",ca );
		return "redirect:/loan";

	}
}*/