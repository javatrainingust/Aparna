package com.ust.training.junit;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

public class CalculatorTest {

	@Test
	public void testAdd() {
		int expectedValue=7;
		Calculator calculator=new Calculator();
		int actualValue=calculator.Add(4, 3);
		assertEquals(expectedValue,actualValue);

	}

	@Test
	public void testSubtract() {
		int expectedValue=1;
		Calculator calculator=new Calculator();
		int actualValue=calculator.Subtract(4, 3);
		assertEquals(expectedValue,actualValue);

	}

}
