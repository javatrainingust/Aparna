/**
 * Cat
 * 
 * The class "Cat" will be acting as the data model for the Cat. 
 * 
 * Date: 05/10/2020
 */

package com.ust.java.collections;

public class Cat implements Comparable<Cat>{
	
	private String name;
	private Integer age;
	
	  /*Argument constructor of Cat*/
	public Cat(String name, int age)
	{
		this.name=name;
		this.age=age;
	}
	
	 /*This method will sort the cat objects with respect to age*/
	@Override
	public int compareTo(Cat o) {
		// TODO Auto-generated method stub
		return age.compareTo(o.age);
	}
	
	/*toString method for printing cat object*/
    @Override
    public String toString() {
        return "Cat [name=" + name + ", age=" + age + "]";
    }

}
