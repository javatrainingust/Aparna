/**
 * StreamInteger
 * 
 * This class is created to have a stream of integers and use map() filter() methods
 * 
 * 09/10/2020
 */

package com.ust.training.stream;

import java.util.stream.Stream;

public class StreamInteger {

	public static void main(String[] args) {

		//Inserting numbers into stream and using map to multiply it and filter to get the numbers greater than 10 and prininting the count
		Stream<Integer> stream= Stream.of(1,2,3,4,5,6,7,8,9);
		long var= stream.map(i -> i*2).filter(n->n>10).count();

		System.out.println(var);


	}

}
