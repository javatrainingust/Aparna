/**
 * StreamOfCat
 * 
 * This class is created to sort cat objects wrt age names using sorting method
 * 
 * 09/10/2020
 */

package com.ust.java.collections;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Stream;

public class StreamOfCat {

	public static void main(String[] args) {
		
		//Creating an ArrayList and adding values for Cat
		List<Cat> list= new ArrayList<Cat>();
		Cat c1= new Cat("Lucy",3);
		Cat c2= new Cat("Dony",8);
		Cat c3= new Cat("Peeku",5);
		Cat c4= new Cat("Kitty",1);
		
		list.add(c1);
		list.add(c2);
		list.add(c3);
		list.add(c4);
		
		//Converting the list into stream and sorting wrt age
		Stream<Cat> stream= list.stream();
		Stream<Cat> result= stream.sorted();
		result.forEach((n)->System.out.println(n));

	}

}
