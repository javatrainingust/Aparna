/**
 * StreamSorting
 * 
 * This class is created to  sort some names using sorting method
 * 
 * 09/10/2020
 */

package com.ust.training.stream;

import java.util.stream.Stream;

public class StrreamSorting {

	public static void main(String[] args) {
		
		//Inserting the names and printing in sorted order
		Stream<String> stream= Stream.of("Delna","Anu","Minu","Bony","Cinu");
		Stream<String> result=stream.sorted();
		result.forEach((n)-> System.out.println(n));

	}

}
