/**
 * 
 * Performer
 * 
 * This interface is created with an abstract method perform
 *  
 * 12-10-2020
 *
 */

package com.ust.java.spring;

public interface Performer {
	
	public void perform();

}
