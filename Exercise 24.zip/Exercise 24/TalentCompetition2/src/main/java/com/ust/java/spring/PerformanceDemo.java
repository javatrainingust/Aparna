/**
 * 
 * PerformanceDemo
 * 
 * Main class method to obtain Singer object from Spring container
 *  
 * 12-10-2020
 *
 */

package com.ust.java.spring;

import org.springframework.context.support.ClassPathXmlApplicationContext;

public class PerformanceDemo {

	public static void main(String[] args) {

		// loading the definitions from the given XML file
		ClassPathXmlApplicationContext context = new ClassPathXmlApplicationContext("applicationContext.xml");

		Singer singer =  context.getBean("singer1",Singer.class);

		singer.perform();

	}

}
