/**
 * 
 * SpringDemo
 * 
 * Main class to get Organizer reference fron spring container
 *  
 * 12-10-2020
 *
 */

package com.ust.java.spring;

import org.springframework.context.support.ClassPathXmlApplicationContext;

public class SpringDemo {

	public static void main(String[] args) {

		// loading the definitions from the given XML file
		ClassPathXmlApplicationContext context = new ClassPathXmlApplicationContext("applicationContext.xml");

		Organizer org =  context.getBean("bean1",Organizer.class);

		org.sayGreetings();

	}

}
