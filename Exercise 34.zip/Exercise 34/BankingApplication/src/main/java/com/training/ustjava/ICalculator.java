package com.training.ustjava;

public interface ICalculator {
	public double CalculateInterest(float amount, float duration);
	
}
