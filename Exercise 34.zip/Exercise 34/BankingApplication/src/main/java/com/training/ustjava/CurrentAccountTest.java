/*
 * package com.training.ustjava;
 * 
 * import static org.junit.jupiter.api.Assertions.*;
 * 
 * import org.junit.jupiter.api.Test;
 * 
 * public class CurrentAccountTest {
 * 
 * @Test public void test() {
 * 
 * String expectedValue= "Overdraft limit is 25000 as balance above 50000";
 * CurrentAccount ca= new CurrentAccount(); String
 * actualValue=ca.CheckOverDraft(90000);
 * assertEquals(expectedValue,actualValue);
 * 
 * }
 * 
 * }
 */