/*
 * package com.training.ustjava;
 * 
 * import static org.junit.jupiter.api.Assertions.*;
 * 
 * import org.junit.jupiter.api.Test;
 * 
 * public class InterestCalculatorTest {
 * 
 * @Test public void test() {
 * 
 * double expectedValue=7; InterestCalculator ic= new InterestCalculator();
 * double actualValue= ic.FixedAccountInterest(1000,1);
 * assertEquals(expectedValue,actualValue);
 * 
 * }
 * 
 * @Test public void test1() {
 * 
 * double expectedValue=3; InterestCalculator ic= new InterestCalculator();
 * double actualValue= ic.SavingsAccountInterest(1000,1);
 * assertEquals(expectedValue,actualValue);
 * 
 * }
 * 
 * }
 */