package com.training.ust.service;
/**
 * 
 *This is the main class for FD Account
 * 
 *06-10-2020
 */

public class FDAccountMain {

	public static void main(String[] args) {
		
		FDAccountService fdservice= new FDAccountService();
		
		fdservice.getAllFDaccountObjects();
		System.out.println("-----------------------------------");
		fdservice.getFDAccountByAccountno(1000);
		System.out.println("-----------------------------------");
		fdservice.deleteFDAccountObject(1001);
		System.out.println("-----------------------------------");
		fdservice.getAllFDaccountObjects();

	}

}
