package com.training.ustjava.codingstn;

/**
 * 
 *Account 
 *
 *Account is class containing getters, setters, parameterized and default constructors
 *
 *30-09-2020
 */

public class Account {		

	private int accountNumber;
	private String holderName;


	public int getAccountNumber() {
		return accountNumber;
	}

	public void setAccountNumber(int accountNumber) {
		this.accountNumber = accountNumber;
	}

	public String getHolderName() {
		return holderName;
	}

	public void setHolderName(String holderName) {
		this.holderName = holderName;
	}

	public Account()
	{
		System.out.println("Inside Base Class no arg constructor");
	}

	public Account(int accountNumber, String holderName)
	{
		System.out.println("Inside Base Class arg constructor " +accountNumber +" " +holderName);
		this.accountNumber=accountNumber;
		this.holderName=holderName;
	}
}
