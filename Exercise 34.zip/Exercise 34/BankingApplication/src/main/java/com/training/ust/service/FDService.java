/*package com.training.ust.service;

import com.training.ustjava.FDAccount;
import com.training.ustjava.ICalculator;
import com.training.ustjava.InterestCalculator;
import com.training.ustjava.Renewable;

public class FDService {

	public static void main(String[] args) {
		
		ICalculator calculator= new InterestCalculator();
		fd.CalculateInterest(20, 2, calculator);
		
		/*Renewable r= new FDAccount();
		r.autorenewable(10);



	}

}
*/