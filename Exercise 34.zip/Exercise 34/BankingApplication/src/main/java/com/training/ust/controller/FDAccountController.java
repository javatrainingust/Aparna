/**
 *FDAccountController
 *
 *This is the controller class for FDAccount
 *
 *06/10/2020
 *
 */

package com.training.ust.controller;


import org.springframework.stereotype.Controller;
import com.training.ust.service.FDAccountService;
import com.training.ustjava.CurrentAccount;
import com.training.ustjava.FDAccount;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;

@Controller
public class FDAccountController {

	@Autowired
	private FDAccountService service;
	
	/**
	 * To add a FDAccount objects and display the  details of each FDAccount.
	 */


	@RequestMapping("/showFd")

	public String showFDAccount(Model model) {

		FDAccount ca = new FDAccount();
		model.addAttribute("key", ca);
		return "addFd";

	}
	
	@RequestMapping("/addfdaccount")
	public String addCurrentAccountObject(@ModelAttribute("fdAccount") FDAccount ca1) {
		
		
		service.addFDAccount(ca1);
		return "redirect:/fd";
		
		
	}


	@RequestMapping("/fd")
	/**
	 * To retrieve all FDAccount objects and display the  details of each FDAccount.
	 */
	public String getAllFdAccount(Model model){

		System.out.println("Inside controller getAllFdAccount");
		List<FDAccount> fd = service.getAllFDaccountObjects();
		model.addAttribute("key",fd );
		return "fdAccountList";

	}
	
	/**
	 * To retrieve and display the FDAccount objects of a specific Account holder
	 */
	
	@RequestMapping("/specificfd")
	public String getSpecificFDAccount(@RequestParam("id") String id, Model model){
		
		FDAccount ca= service.getFDAccountByAccountno(Integer.parseInt(id));
		model.addAttribute("key1",ca );
		return "viewFdAccount";

	}
	
	/**
	 * To delete an account using accountno and to display the rest of FDAccount 
	 */
	
	@RequestMapping("/deletefd")
	public String deleteSpecificFDtAccount(@RequestParam("id") String id, Model model){
		
		service.deleteFDAccountObject(Integer.parseInt(id));
		return "redirect:fd ";

	}

}



