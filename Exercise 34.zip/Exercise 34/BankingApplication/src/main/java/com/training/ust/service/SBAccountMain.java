package com.training.ust.service;
/**
 * 
 *This is the main class for SB Account
 * 
 *06-10-2020
 */

public class SBAccountMain {

	public static void main(String[] args) {

		SBAccountService sbservice= new SBAccountService();

		/*
		 * sbservice.getAllSBAccountObjects();
		 * System.out.println("-----------------------------------");
		 * sbservice.getSBAccountByAccountno(1000);
		 * System.out.println("-----------------------------------");
		 * sbservice.deleteSBAccountObject(1000);
		 * System.out.println("-----------------------------------");
		 * sbservice.getAllSBAccountObjects();
		 */
		sbservice.withdrawMoney(300);
	}

}
