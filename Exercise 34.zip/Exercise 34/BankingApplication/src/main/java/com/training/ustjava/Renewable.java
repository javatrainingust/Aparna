package com.training.ustjava;

public interface Renewable {

	public void autorenewable(int tenure);


}
