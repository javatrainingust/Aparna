/**
 * 
 *LoanAccount is the extended class of base class Account containing variables and constructors
 *
 *30-09-2020
 */

package com.training.ustjava;

import java.util.Comparator;



public class LoanAccount extends Account implements Comparator<LoanAccount>, Comparable<LoanAccount>{

	//int tenure=12;
	public float loanOutstanding;
	
	//Non arg constructor
	public LoanAccount() {
		super();
	}
//Parameterized construcor
	public LoanAccount(int accountNo, String holderName, float loanOutstanding)
	{
		super(accountNo,holderName);
		this.loanOutstanding=loanOutstanding;
	}
/**
 * Comparable and comparator methods
 */
	
	public int compareTo(LoanAccount o) {
		// TODO Auto-generated method stub
		return this.holderName.compareTo(o.getHolderName());
	}

	
	public int compare(LoanAccount o1, LoanAccount o2) {
		// TODO Auto-generated method stub
		return (int) (o1.loanOutstanding-o2.loanOutstanding);
	}

	/*
	 * public void CalculateEmi(float loanTaken) { float emi= loanTaken/tenure;
	 * loanOutstanding=loanTaken-emi; System.out.println("Emi for loan amount "
	 * +loanTaken +" is: " +emi);
	 * System.out.println("Loan Outstanding Amount after emi remittance is: "
	 * +loanOutstanding); }
	 */

}
