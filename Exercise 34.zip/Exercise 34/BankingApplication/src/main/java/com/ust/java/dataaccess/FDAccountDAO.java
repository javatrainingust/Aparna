package com.ust.java.dataaccess;

/**
 * 
 *FDAccountDAO is the interface with the specified 3 methods
 *
 *06-10-2020
 */

import java.util.List;

import com.training.ustjava.Account;
import com.training.ustjava.FDAccount;

public interface FDAccountDAO {
			
		public List<FDAccount> getAllFDAccountObjects();
		public FDAccount getFDAccountByAccountno(int accountNo);
		public void deleteFDAccountObject(int accountNo);
		public boolean addFDAccountObject(FDAccount fd);
		public void updateFDAccountObject(FDAccount fdAccount);

}
