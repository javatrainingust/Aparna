/**
 * SBAccountDAOSQLImpl
 * 
 * Class that implements SBAccountDAO Interface
 * 
 *  23-10-2020
 */

package com.ust.java.dataaccess;

import java.util.List;
import javax.sql.DataSource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;
import com.training.ustjava.SBAccount;

@Repository
public class SBAccountDAOSQLImpl implements SBAccountDAO {

	private DataSource dataSource;
	private JdbcTemplate jdbcTemplateObject;

	/**
	 * This method sets a template's data source to a JDBC resultset.
	 */
	
	@Autowired
	public void setDataSource(DataSource dataSource) {
		this.dataSource = dataSource;
		jdbcTemplateObject = new JdbcTemplate(dataSource);
	}

	/**
	 * This method is to retrieve and print all sbaccount details
	 */
	
	public List<SBAccount> getAllSBAccountObjects() {
		String SQL = "select * from sbAccount";
		List <SBAccount> sbAccount= jdbcTemplateObject.query(SQL, new BankingMapperSBAccount());
		return sbAccount;
	}

	/**
	 * This method is to retrieve destails of specific account no
	 */
	
	public SBAccount getSBAccountByAccountno(int accountNo) {
		String sql = "SELECT * FROM sbAccount WHERE accountNo = ?";
		SBAccount sbaccount = (SBAccount) jdbcTemplateObject.queryForObject(
				sql, new Object[] { accountNo }, new BankingMapperSBAccount());
		return 	sbaccount;	
	}

	/**
	 * This method is to delete details of specific account no
	 */
	
	public void deleteSBAccountObject(int accountNo) {
		String query="delete from sbAccount where id='"+accountNo+"' ";  
		jdbcTemplateObject.update(query);  
	}

	/**
	 * This method is to add details
	 */
	public boolean addSBAccountObject(SBAccount fd) {
		String sql = "INSERT INTO sbAccount " +
				"(ACCOUNTNUMBER, HOLDERNAME) VALUES (?,?)";
		jdbcTemplateObject.update(sql, new Object[] { fd.getAccountNo(), fd.getHolderName()
		});
		return true;
	}

	/**
	 * This method is to update details for a specific account no
	 */
	
	public void updateSBAccountObject(SBAccount sbccount) {
		String query="update sbAccount set  Number='"+ sbccount.getAccountNo()+"',Name='"+ sbccount.getHolderName();
		jdbcTemplateObject.update(query);  
	}

}

