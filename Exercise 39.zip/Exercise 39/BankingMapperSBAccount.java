/**
 * BankingMapperSBAccount
 * 
 * Mapper class that implements RowMapper Interface
 * 
 *  23-10-2020
 * 
 */

package com.ust.java.dataaccess;

import java.sql.ResultSet;
import java.sql.SQLException;
import org.springframework.jdbc.core.RowMapper;
import com.training.ustjava.SBAccount;

//RowMapper interface is used by JdbcTemplate for mapping rows of a ResultSet on a per-row basis
public class BankingMapperSBAccount implements RowMapper<SBAccount> {

	/**
	 * Method is used to map sbaccount records to SBAccount object 
	 */
	public SBAccount mapRow(ResultSet rs, int rowNum) throws SQLException {

		SBAccount sb =  new SBAccount();
		sb.setAccountNo(rs.getInt("Number"));
		sb.setHolderName(rs.getString("Name"));
		return sb;
	}

}


