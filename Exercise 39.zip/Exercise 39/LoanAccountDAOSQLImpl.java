/**
 * LoanAccountDAOSQLImpl
 * 
 * Class that implements LoanAccountDAO Interface
 * 
 *  23-10-2020
 */

package com.ust.java.dataaccess;

import java.util.List;
import javax.sql.DataSource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;
import com.training.ustjava.LoanAccount;

@Repository
public class LoanAccountDAOSQLImpl implements LoanAccountDAO {

	private DataSource dataSource;
	private JdbcTemplate jdbcTemplateObject;

	/**
	 * This method sets a template's data source to a JDBC resultset.
	 */

	@Autowired
	public void setDataSource(DataSource dataSource) {
		this.dataSource = dataSource;
		jdbcTemplateObject = new JdbcTemplate(dataSource);
	}

	/**
	 * This method is to retrieve and print all loan account details
	 */

	public List<LoanAccount> getAllLoanAccountObjects() {
		String SQL = "select * from loanAccount";
		List <LoanAccount> loanAccount= jdbcTemplateObject.query(SQL, new BankingMapperLoanAccount());
		return loanAccount;
	}

	/**
	 * This method is to retrieve details of specific account no
	 */

	public LoanAccount getLoanAccountByAccountno(int accountNo) {
		String sql = "SELECT * FROM loanAccount WHERE accountNo = ?";
		LoanAccount loanAccount = (LoanAccount) jdbcTemplateObject.queryForObject(
				sql, new Object[] { accountNo }, new BankingMapperLoanAccount());
		return 	loanAccount;	
	}

	/**
	 * This method is to delete details of specific account no
	 */

	public void deleteLoanAccountObject(int accountNo) {
		String query="delete from loanAccount where id='"+accountNo+"' ";  
		jdbcTemplateObject.update(query);  
	}

	/**
	 * This method is to add details
	 */

	public boolean addLoanAccountObject(LoanAccount fd) {
		String sql = "INSERT INTO loanAccount " +
				"(ACCOUNTNUMBER, HOLDERNAME) VALUES (?,?)";
		jdbcTemplateObject.update(sql, new Object[] { fd.getAccountNo(), fd.getHolderName()
		});
		return true;
	}

	/**
	 * This method is to update details for a specific account no
	 */

	public void updateLoanAccountObject(LoanAccount loanccount) {
		String query="update loanAccount set  Number='"+ loanccount.getAccountNo()+"',Name='"+ loanccount.getHolderName();
		jdbcTemplateObject.update(query);  
	}
}