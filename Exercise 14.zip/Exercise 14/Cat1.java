package com.ust.java.collections;

/**
 * The class "Cat1" will be acting as the data model for the Cat. 
 * Date: 05/10/2020
 */

public class Cat1 implements CatInterface
{
	/*Argument constructor of Cat1*/
	public Cat1(String name, int age)
	{
		this.name=name;
		this.age=age;
	}			
			private String name;
			private Integer age;
			
			public String getName() {
				return name;
			}

			public Integer getAge() {
				return age;
			}
	
			public boolean equals1(Object obj) 
			{
				Cat1 cat = (Cat1)obj;
				boolean isEqual = false;
				if((this.age.equals( cat.age)) && (this.name.equals( cat.name))) 
				{
					isEqual =true;
				}
				return isEqual;
			}
			
			/*toString method for printing cat object*/
		    @Override
		    public String toString() {
		        return "Cat [name=" + name + ", age=" + age + "]";
		    }

			@Override
			public int hashCode() {
				final int prime = 31;
				int result = 1;
				result = prime * result + ((age == null) ? 0 : age.hashCode());
				return result;
			}

			@Override
			public boolean equals(Object obj) {
				if (this == obj)
					return true;
				if (obj == null)
					return false;
				if (getClass() != obj.getClass())
					return false;
				Cat1 other = (Cat1) obj;
				if (age == null) {
					if (other.age != null)
						return false;
				} else if (!age.equals(other.age))
					return false;
				return true;
			}

			@Override
			public void sleep() {
				System.out.println("Cat is sleeping");
				
			}

	}

