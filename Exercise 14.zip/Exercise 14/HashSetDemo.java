package com.ust.java.collections;

import java.util.HashSet;
import java.util.Set;

public class HashSetDemo {

	public static void main(String[] args) {
	
		
		Set s = new HashSet();
		
		boolean b[]= new boolean[3];
		
		b[0] = s.add("test");
		
		b[1] = s.add("work");
		
		b[2] = s.add("test");
				
		for (int i=0; i<b.length; i++) 
		{
			
			System.out.println("Value inside boolean array:"+b[i]);
		}
	
	for(Object o:s) 
	{
		
		System.out.println("Value inside Set:"+o);
	}
	}

}
