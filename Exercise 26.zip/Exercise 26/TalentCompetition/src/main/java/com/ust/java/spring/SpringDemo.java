/**
 * 
 * SpringDemo
 * 
 * Main class to get Organizer reference from spring container
 *  
 * 12-10-2020
 *
 */

package com.ust.java.spring;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class SpringDemo {

	public static void main(String[] args) {

		// loading the definitions from OrganizerSpring class
		AnnotationConfigApplicationContext context = new AnnotationConfigApplicationContext(OrganizerSpring.class);

		Organizer org = context.getBean("bean1",Organizer.class);

		org.sayGreetings();


	}

}
