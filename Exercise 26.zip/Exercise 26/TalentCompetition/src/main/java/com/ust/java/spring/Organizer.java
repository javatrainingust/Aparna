/**
 * 
 * Organizer
 * 
 * This class contain a method sayGreetings
 *  
 * 12-10-2020
 *
 */

package com.ust.java.spring;

public class Organizer {
	
	/**
	 * Method with a sysout
	 */

	public void sayGreetings()
	{
		System.out.println("Welcome to talent competition");
	}

}
