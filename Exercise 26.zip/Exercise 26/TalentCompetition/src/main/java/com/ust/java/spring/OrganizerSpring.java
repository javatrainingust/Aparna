/**
 * 
 * OrganizerSpring
 * 
 * Java configuration class with @Configuration annotation and use @Bean annotation to create Organizer object.
 *  
 * 13-10-2020
 *
 */

package com.ust.java.spring;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class OrganizerSpring {
	
	//Bean annotation to create Organizer object
	@Bean(name = "bean1")
	
	/**
	 * Get method to call the method of Organizer
	 */
	public Organizer getOrganizer() {
		
		System.out.println("Inside getOrganizer() method of SpringConfig class");
		Organizer org = new Organizer();
		org.sayGreetings();
		return org;
	}
}