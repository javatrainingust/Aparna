/**
 * 
 * Singer
 * 
 * This method is created to implement the interface Performer
 *  
 * 12-10-2020
 *
 */

package com.ust.java.spring;

public class Singer implements Performer {

	public String song;
	
	/**
	 * 
	 * Method to inject value for Singer bean through constructor
	 *
	 */
	
	public Singer(String s) {
		song=s;
		
	}
	
	/**
	 * 
	 * Method to implement the method perform of interface
	 *
	 */


	public void perform() {
		System.out.println("Song is sung by "+ this.song);
	}


}
