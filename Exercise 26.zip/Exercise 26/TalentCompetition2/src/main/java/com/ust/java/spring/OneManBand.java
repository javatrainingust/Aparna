/**
 * OneManBand
 * 
 * OneManBand implements Performer interface.
 *  
 * 12-10-2020
 */

package com.ust.java.spring;

import java.util.*;

public class OneManBand implements Performer {

	//property of Instrument of List
	List<Instrument> instruments;

	/**
	 * Method to iterate the collection of instruments and call play() method
	 */
	public void perform() {

		for( Instrument i: instruments)
		{
			i.play();
		}

	}
	
	/**
	 * Getter and setter methods of list of instruments
	 */

	public List<Instrument> getInstruments() {
		return instruments;
	}

	public void setInstruments(List<Instrument> instruments) 
	{
		this.instruments = instruments;
	}

}
