/**
 * Guitar
 * 
 * This class implements the interface Instrument
 *  
 * 12-10-2020
 */

package com.ust.java.spring;

public class Guitar implements Instrument {
	
public void play() {
		
		System.out.println("Guitar is played");

	}

}
