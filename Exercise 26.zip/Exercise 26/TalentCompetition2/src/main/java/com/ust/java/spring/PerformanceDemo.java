/**
 * 
 * PerformanceDemo
 * 
 * Main class method to obtain Singer object and Instrumentalist object from Spring container
 *  
 * 12-10-2020
 *
 */

package com.ust.java.spring;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class PerformanceDemo {

	public static void main(String[] args) {

		/*
		 * // loading the definitions from the given XML file
		 * ClassPathXmlApplicationContext context = new
		 * ClassPathXmlApplicationContext("applicationContext.xml");
		 * 
		 * Singer singer = context.getBean("singer1",Singer.class);
		 * 
		 * singer.perform();
		 */

		// loading the definitions from the given XML file
		AnnotationConfigApplicationContext context = new AnnotationConfigApplicationContext(SpringConfig.class);

		Instrumentalist  instrumentalist  =  context.getBean("instrumentalist",Instrumentalist.class);

		instrumentalist.perform();

	}

}
