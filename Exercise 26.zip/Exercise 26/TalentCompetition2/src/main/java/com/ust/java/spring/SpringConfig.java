package com.ust.java.spring;

import org.springframework.context.annotation.Bean;

public class SpringConfig {

	@Bean(name= "instrumentalist")
	public  Instrumentalist getInstrumentalist() {

		System.out.println("Inside getInstrumentalist() method of SpringConfig class");
		Instrumentalist instrumentalist = new Instrumentalist();
		instrumentalist.setSax(getSaxophone());
		return instrumentalist;
	}

	@Bean()
	public  Saxophone getSaxophone() {

		System.out.println("Inside getSaxophone() method of SpringConfig class");
		Saxophone saxophone = new Saxophone();
		return saxophone;

	}
}
