/**
 * CollectionDemo
 * 
 * Main class to obtain the OneManBand object from the spring container and call the perform() method.
 *  
 * 12-10-2020
 */

package com.ust.java.spring;

import org.springframework.context.support.ClassPathXmlApplicationContext;

public class CollectionDemo {

	public static void main(String[] args) {

		// loading the definitions from the given XML file
		ClassPathXmlApplicationContext context = new ClassPathXmlApplicationContext("applicationContext.xml");

		OneManBand  oneManBand  =  context.getBean("onemanband",OneManBand.class);
		oneManBand.perform();

	}

}
