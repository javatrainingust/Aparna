/**
 * 
 * SupplierDemo
 * 
 * This class is created to display a random number using Functional Interface
 * 
 * 08/10/2020
 */

package com.ust.training.functionalinterfac;

import java.util.function.*;;

public class SupplierDemo {

	public static void main(String[] args) {
		
		// Lambda expression to generate a random number using Supplier Interface
		Supplier<Double> supplier=()->Math.random();
		System.out.println(supplier.get());

	}

}
