/**
 * PredicateDemo
 * 
 * This class is created to change case to upper case of a given string using Predicate Interface
 * 
 * 08/10/2020
 */

package com.ust.training.functionalinterfac;

import java.util.function.Predicate;

public class PredicateDemo {

	public static void main(String[] args) {
		
		//Lambda expression to check whether the number is greater than 50 using predicate interface
		Predicate<Integer> predicate= (n) -> n>50;
		System.out.println(predicate.test(10));
		

	}

}
