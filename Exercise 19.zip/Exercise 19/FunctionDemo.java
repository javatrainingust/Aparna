/**
 * PredicateDemo
 * 
 * This class is created to change case to upper case of a given string using Predicate Interface
 * 
 * 08/10/2020
 */

package com.ust.training.functionalinterfac;

import java.util.function.Function;

public class FunctionDemo {

	public static void main(String[] args) {
		
		String s= "hello";
		
		//Lambda expression to convert the string s into uppercase
		Function<String, String> function= (str) -> 
		{
			System.out.println(str.toUpperCase());
			return str;
		};
		
		function.apply(s);
	}

}
