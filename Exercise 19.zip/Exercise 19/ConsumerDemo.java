/**
 * ConsumerDemo
 * 
 * This class is created to change case to upper case of a given string using Consumer Interface
 * 
 * 08/10/2020
 */

package com.ust.training.functionalinterfac;

import java.util.function.Consumer;

public class ConsumerDemo {

	public static void main(String[] args) {

		//Inputting a string  and splitting it in to a char array
		String s= "hello";
		char[] c=s.toCharArray();

		//Lambda expression to covert each character into uppercase
		Consumer<String> consumer= (str) ->
		{
			for( int i=0; i<c.length;i++) 
			{
				System.out.println();
				Character cha= Character.toUpperCase(c[i]);
				System.out.println(cha);
			}

		};
		
		consumer.accept(s);
	}
}