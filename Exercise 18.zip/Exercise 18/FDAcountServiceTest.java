/***
 * FDAccountServiceTest 
 * 
 *  This is test class for FDAccountService
 * 
 * 07-10-2020
 * */

package com.training.ust.service;

import static org.junit.jupiter.api.Assertions.*;

import java.util.List;

import org.junit.jupiter.api.Test;

import com.training.ustjava.CurrentAccount;
import com.training.ustjava.FDAccount;

class FDAcountServiceTest {

	/* for getting all accounts sorted by names */

	/*
	 * @Test public void testSortedByNames() { String expectedValue ="Anna";
	 * FDAccountService fdAccountService=new FDAccountService(); List<FDAccount>
	 * fdAccountServiceList=fdAccountService.getAllFDAccountObjectsSortByName();
	 * String actualValue= fdAccountServiceList.get(0).getholdernamee();
	 * assertEquals(expectedValue,actualValue); } for getting all accounts sorted by
	 * balance
	 * 
	 * 
	 * @Test public void testSortedByBalance() { float expectedValue =2000;
	 * FDAccountService fdAccountService=new FDAccountService(); List<FDAccount>
	 * fdAccountServiceList=fdAccountService.getAllFDAccountObjectsSortByAmount();
	 * float actualValue=fdAccountServiceList.get(0).amount;
	 * assertEquals(expectedValue,actualValue,0.0f); }
	 */
	
	@Test
	public void testAdd() {
		FDAccount fdAccount = new FDAccount(1000, "Aparna", 20000,2);
		FDAccountService fdAccountService = new FDAccountService();
		fdAccountService.addFDAccount(fdAccount);
		assertEquals(1, fdAccountService.getAllFDaccountObjects().size());
	}
	
	@Test
	public void testUpdate() {
		FDAccount fdAccount1 = new FDAccount(1000, "Aparna", 20000,3);
		FDAccount fdAccount2 = new FDAccount(1000, "Appu", 30000,8);
		FDAccountService fdAccountService = new FDAccountService();
		fdAccountService.addFDAccount(fdAccount1);
		fdAccountService.addFDAccount(fdAccount2);
		
		fdAccountService.updateFDAccount(fdAccount2);
		assertEquals(1, fdAccountService.getAllFDaccountObjects().size());
	}

}
