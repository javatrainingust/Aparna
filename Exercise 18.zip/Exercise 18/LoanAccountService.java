/**
 *LoanAccountService
 *
 *This is the service class for LoanAccount
 *
 *06/10/2020
 *
 */

package com.training.ust.service;

import java.util.Collections;
import java.util.Iterator;
import java.util.List;

import com.training.ustjava.CurrentAccount;
import com.training.ustjava.FDAccount;
import com.training.ustjava.LoanAccount;
import com.training.ustjava.SBAccount;
import com.ust.java.dataaccess.CurrentAccountDAO;
import com.ust.java.dataaccess.CuurentAccountDAOImpl;
import com.ust.java.dataaccess.LoanAccountDAO;
import com.ust.java.dataaccess.LoanAccountDAOImpl;

public class LoanAccountService {

	LoanAccountDAO daoImpl;

	public LoanAccountService() {

		daoImpl=new LoanAccountDAOImpl() ;
	}
/**
 * Method to print all the enteries
 */
	public List<LoanAccount> getAllLoanAccountObjects() {
		List<LoanAccount> LoanAccountList= daoImpl.getAllLoanAccountObjects();
		Iterator<LoanAccount>  iterator = LoanAccountList.iterator();

		while(iterator.hasNext()){

			LoanAccount la = iterator.next();

			System.out.println("Account Number: "+la.getaccountnumber());
			System.out.println("Holder name: "+la.getholdernamee());
			System.out.println("Loan Amount Outstanding: "+la.loanOutstanding);
		}

		return LoanAccountList;
	}


	/**
	 * 
	 * Method to retreive one record for given account no
	 */
	public LoanAccount getLoanAccountByAccountno(int accountNo) 
	{
		LoanAccount la = daoImpl.getLoanAccountByAccountno(accountNo);
		System.out.println("Account Number: "+la.getaccountnumber());
		System.out.println("Holder name: "+la.getholdernamee());
		System.out.println("Loan Outstanding Amount: "+la.loanOutstanding);

		return la;
	}

	/**
	 * Method to delete the entry for given account no
	 * 
	 */
	public void deleteCurrentAccountObject(int accountNo) {
		daoImpl.deleteLoanAccountObject(accountNo);
	}
	
	/**
	 * Method to sort the details of customer by name
	 */

	public List<LoanAccount> getAllLoanAccountObjectsSortByName()
	{
		List<LoanAccount> loanAccountList= daoImpl.getAllLoanAccountObjects();
		Collections.sort(loanAccountList);

		Iterator<LoanAccount> iterator= loanAccountList.iterator();
		while(iterator.hasNext())
		{
			LoanAccount fd = iterator.next();

			System.out.println("Account Number: "+fd.getaccountnumber());
			System.out.println("Holder name: "+fd.getholdernamee());
			System.out.println("Loan balance" +fd.loanOutstanding);
		}

		return loanAccountList;

	}

	/**
	 * Method to sort the details of customer by amount
	 */

	public List<LoanAccount> getAllLoanAccountObjectsSortByBalance()
	{
		List<LoanAccount> loanAccountList= daoImpl.getAllLoanAccountObjects();
		Collections.sort(loanAccountList, new LoanAccount());

		Iterator<LoanAccount> iterator= loanAccountList.iterator();
		while(iterator.hasNext())
		{
			LoanAccount fd = iterator.next();

			System.out.println("Account Number: "+fd.getaccountnumber());
			System.out.println("Holder name: "+fd.getholdernamee());
			System.out.println("Balance" +fd.loanOutstanding);

		}

		return loanAccountList;

	
	}
	
	/**
	 * Method to add a new entry
	 */
	
	public void addLoanAccount(LoanAccount loanAccount)
	{
		boolean isAdded=daoImpl.addLoanAccountObject(loanAccount);
		
		if(!isAdded) {
			System.out.println("Already exist");
		}
		else
			System.out.println("Added");
		}
	/**
	 * Method to update an entry
	 */
	
	public void updateLoanAccount(LoanAccount loanAccount)
	{
		daoImpl.updateLoanAccountObject(loanAccount);
	}

}
