package com.ust.java.dataaccess;

/**
 * 
 *CurrentAccountDAO is the interface with the specified 3 methods
 *
 *06-10-2020
 */

import java.util.List;

import com.training.ustjava.CurrentAccount;

public interface CurrentAccountDAO {
	
	public List<CurrentAccount> getAllCurrentAccountObjects();
	public CurrentAccount getCurrentAccountByAccountno(int accountNo);
	public void deleteCurrentAccountObject(int accountNo);
	public boolean addCurrentAccountObject(CurrentAccount ca);
	public void updateCurrentAccountObject(CurrentAccount currentAccount);

}
