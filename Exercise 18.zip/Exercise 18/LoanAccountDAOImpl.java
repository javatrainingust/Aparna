package com.ust.java.dataaccess;
/**
 * 
 *LoanAccountDAOImpl is the implementation class for LoanAccountDAO
 * 
 *06-10-2020
 */

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

import com.training.ustjava.FDAccount;
import com.training.ustjava.LoanAccount;

public class LoanAccountDAOImpl implements LoanAccountDAO {

	List<LoanAccount> LoanAccountList;
	Set<LoanAccount> loanAccountSet;
	public LoanAccountDAOImpl() {

		LoanAccountList= new ArrayList<LoanAccount>();
		loanAccountSet= new HashSet<LoanAccount>();
		/*
		 * LoanAccount la1= new LoanAccount(1000, "Aparna",2000); LoanAccount la2= new
		 * LoanAccount(1001, "Arun", 4000); LoanAccount la3= new LoanAccount(1002,
		 * "Anna", 6000); LoanAccount la4= new LoanAccount(1003, "Minu", 6000);
		 * LoanAccount la5= new LoanAccount(1004, "Delna", 8000);
		 * 
		 * LoanAccountList.add(la1); LoanAccountList.add(la2); LoanAccountList.add(la3);
		 * LoanAccountList.add(la4); LoanAccountList.add(la5);
		 */
	}


	@Override
	public List<LoanAccount> getAllLoanAccountObjects() {
		// TODO Auto-generated method stub
		return LoanAccountList;
	}

	@Override
	public LoanAccount getLoanAccountByAccountno(int accountNo) {
		LoanAccount loanAccount=null;

		Iterator<LoanAccount> iterator=LoanAccountList.iterator();
		while(iterator.hasNext())
		{
			LoanAccount la=iterator.next();
			if(la.getaccountnumber()==accountNo)
				loanAccount=la;

		}
		return loanAccount;
	}

	@Override
	public void deleteLoanAccountObject(int accountNo) {

		for(int i=0; i< LoanAccountList.size(); i++){
			LoanAccount la =(LoanAccount)LoanAccountList.get(i);
			if(la.getaccountnumber()==accountNo)
			{
				LoanAccountList.remove(i);
			}


		}
	}
	
	/**
	 * 
	 * Method to add a new entry
	 */

	public boolean addLoanAccountObject(LoanAccount fd)
	{

		boolean isAdded= loanAccountSet.add(fd);
		if(isAdded)
		{
			LoanAccountList.add(fd);
		}
		return isAdded;
	}
	/**
	 * Method to update an entry

	 */

	public void updateLoanAccountObject(LoanAccount loanccount)
	{
		Iterator iterator= LoanAccountList.iterator();

		while(iterator.hasNext())
		{
			LoanAccount fd= (LoanAccount)iterator.next();
			if(fd.getaccountnumber()==loanccount.getaccountnumber())
			{
				fd.setholdername(loanccount.getholdernamee());
				fd.setaccountnumber(loanccount.getaccountnumber());
			}

		}

	}
}