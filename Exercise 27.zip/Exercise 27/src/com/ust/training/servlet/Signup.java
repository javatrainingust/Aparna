/**
 * Signup
 * 
 * This is a model class having instance variables and their getters and setters
 * 
 * 14-10-2020
 */

package com.ust.training.servlet;

public class Signup {

		private String userName;
		private String userId;
		private String password;
		private String confirmPassword;
		
		public String getUserName() {
			return userName;
		}
		public void setUserName(String userName) {
			this.userName = userName;
		}
		public String getUserId() {
			return userId;
		}
		public void setUserId(String userId) {
			this.userId = userId;
		}
		public String getPassword() {
			return password;
		}
		public void setPassword(String password) {
			this.password = password;
		}
		public String getConfirmPassword() {
			return confirmPassword;
		}
		public void setConfirmPassword(String confirmPassword) {
			this.confirmPassword = confirmPassword;
		}
		
}
