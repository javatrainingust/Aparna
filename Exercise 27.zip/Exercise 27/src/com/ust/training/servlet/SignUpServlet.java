/**
 * SignUpServlet
 * 
 * Servlet
 * 
 * 14-10-2020
 */

package com.ust.training.servlet;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class SignUpServlet
 */
@WebServlet("/SignUpServlet")
public class SignUpServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public SignUpServlet() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * 
	 * doPost method retrieve values from request and create object of Signup then set the values. Store the Signup object in request using setAttribute() and Transfer control to confirm.jsp
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		Signup signup = new Signup();

		signup.setUserName(request.getParameter("userName"));
		signup.setUserId(request.getParameter("userId"));
		signup.setPassword(request.getParameter("password"));
		signup.setConfirmPassword(request.getParameter("confirmPassword"));


		request.setAttribute("key", signup);

		request.getRequestDispatcher("confirm.jsp").forward(request,response);
	}

}
