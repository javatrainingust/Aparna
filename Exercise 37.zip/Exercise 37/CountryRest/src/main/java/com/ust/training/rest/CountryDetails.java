/**
 * CountryDetails
 * 
 * CountryDetails class is the model class for the controller class CountryDetails 
 * 
 * 22-10-2020
 */

package com.ust.training.rest;

public class CountryDetails {

	private String code;
	private String description;
	private String message;


	/**
	* Getter method for variable message
	*/
	public String getMessage() {
		return message;
	}

	/**
	* Setter method for variable message
	*/
	public void setMessage(String message) {
		this.message = message;
	}

	/**
	 * Getter method for variable code
	 */
	public String getCode() {
		return code;
	}

	/**
	 * Setter method for variable code
	 */
	public void setCode(String code) {
		this.code = code;
	}

	/**
	 * Getter method for variable description
	 */
	public String getDescription() {
		return description;
	}

	/**
	 * Setter method for variable description
	 */
	public void setDescription(String description) {
		this.description = description;
	}


}
