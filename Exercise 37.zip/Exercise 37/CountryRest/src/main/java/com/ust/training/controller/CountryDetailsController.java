/**
 * CountryDetailsControllerntryDetails
 * 
 * CountryDetailsController is the controller class for the model class CountryDetails 
 * 
 * 22-10-2020
 */

package com.ust.training.controller;

import java.util.*;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import com.ust.training.rest.CountryDetails;

//RestController annotation is used to create RESTful web services
@RestController
public class CountryDetailsController {

	//HashMap to store the CountryDetails objects using code as key and CountryDetails object as value
	Map<String,CountryDetails> CountryDB= new HashMap<String,CountryDetails>();

	/**
	 * GET method to insert details of one country to the Map
	 */
	@RequestMapping(value= "country/dummy", method= RequestMethod.GET)
	public  CountryDetails getDummyCountry()
	{
		CountryDetails country= new  CountryDetails();
		country.setCode("IN");
		country.setDescription("India");
		CountryDB.put("IN", country);
		return country;

	}

	/**
	 * To create CountryDetails using POST method
	 */	
	@RequestMapping(value= "country/create", method= RequestMethod.POST)
	public  CountryDetails createCountryDetails(@RequestBody CountryDetails country)
	{
		System.out.println("Get code" +country.getCode());
		if(CountryDB.containsKey(country.getCode())) 
		{
			country.setMessage("Country already exist");
		}
		else
		{
			CountryDB.put(country.getCode(), country);
			country.setMessage("Created the country");
		}

		return country;		

	}

	/**
	 * To retrieve all the country details using GET method
	 */
	@RequestMapping(value= "country/retrieve", method= RequestMethod.GET)
	public  List<CountryDetails> getAllDetails()
	{		
		List<CountryDetails> countryList= new ArrayList<CountryDetails>();
		Set<String> keySet= CountryDB.keySet();
		for(String key: keySet)
		{
			countryList.add(CountryDB.get(key));
		}
		return countryList;
	}

	/**
	 * To retrieve a specific country detail for code using GET
	 */
	@RequestMapping(value= "country/retrieve/{id}", method= RequestMethod.GET)
	public  CountryDetails getSpecificDetails(@PathVariable int id)
	{		
		CountryDetails country= new CountryDetails();
		if(CountryDB.containsKey(id))
		{
			country= CountryDB.get(id);
			country.setMessage("Country details retrieved");
		}
		else
		{
			System.out.println("No details found");
		}
		return country;
	}
	
	/**
	 * To update a specific country details for code using PUT
	 */
	@RequestMapping(value= "country/retrieve/update/{id}", method= RequestMethod.PUT)
	public  CountryDetails updateSpecificDetails(@PathVariable String id, @RequestBody CountryDetails modified)
	{		
		CountryDetails country= new CountryDetails();
		if(CountryDB.containsKey(id))
		{
			country= CountryDB.get(id);
			country.setDescription(modified.getDescription());
			country.setMessage("Country details updated");
		}
		else
		{
			System.out.println("No details found");
		}
		return country;
	}
	
	/**
	 * To delete a specific country details for code using DELETE
	 */
	@RequestMapping(value= "country/delete/{id}", method= RequestMethod.DELETE)
	public  CountryDetails deleteSpecificDetails(@PathVariable String id)
	{		
		CountryDetails country= new CountryDetails();
		if(CountryDB.containsKey(id))
		{
			country= CountryDB.get(id);
			CountryDB.remove(id);
			country.setMessage("Country details deleted");
		}
		else
		{
			System.out.println("No details found");
		}
		return country;
	}

}
