/**
 * CurrentAccountController
 * 
 * Controller class
 * 
 * 15-10-2020
 */


package com.training.ust.controller;

import org.springframework.stereotype.Controller;
import com.training.ust.service.CurrentAccountService;
import com.training.ustjava.CurrentAccount;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;

@Controller
public class CurrentAccountController {

	@Autowired
	private CurrentAccountService service;


	@RequestMapping("/current")

	/**
	 * To retrieve all FDAccount objects and display the  details of each FDAccount.
	 */
	public String getAllCurrentAccount(Model model){

		System.out.println("Inside controller getAllCurrentAccount");
		List<CurrentAccount> ca = service.getAllCurrentAccountObjects();

		model.addAttribute("key",ca );
		return "currentAccountList";

	}

}





