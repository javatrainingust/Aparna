package com.training.ustjava;

import static org.junit.Assert.assertEquals;
import static org.junit.jupiter.api.Assertions.*;
import java.util.*;
import org.junit.jupiter.api.Test;

import com.ust.java.dataaccess.FDAccountDAO;
import com.ust.java.dataaccess.FDAccountDAOImpl;


class FDAccountDAOImplTest {
	List<FDAccount> FDAccountList;
	FDAccountDAO accountDAO;

	public FDAccountDAOImplTest()
	{
		accountDAO = new FDAccountDAOImpl();
	}

	@Test
	void getAllFDAccountObjectsTest() {
		int count = accountDAO.getAllFDAccountObjects().size();
		assertEquals(5,count);
	}

	@Test
	void getFDAccountByAccountnoTest() {
		FDAccount account = accountDAO.getFDAccountByAccountno(1000);
		assertEquals("Aparna",account.getholdernamee());
	}

	@Test
	void deleteFDAccountObjectTest() {
		accountDAO.deleteFDAccountObject(1000);
		int count = accountDAO.getAllFDAccountObjects().size();
		assertEquals(4,count);
	}

}
