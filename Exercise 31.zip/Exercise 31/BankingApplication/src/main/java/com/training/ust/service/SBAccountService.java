/**
 *SBAccountService
 *
 *This is the service class for SBAccount
 *
 *06/10/2020
 *
 */

package com.training.ust.service;

import java.util.Iterator;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.training.ustjava.InsufficientBalanceException;
import com.training.ustjava.SBAccount;
import com.ust.java.dataaccess.SBAccountDAO;
import com.ust.java.dataaccess.SBAccountDAOImpl;

@Service
public class SBAccountService {

	@Autowired
	SBAccountDAO daoImpl;

	public SBAccountService() {

		daoImpl=new SBAccountDAOImpl() ;
	}
	/**
	 * Method for printing all the enteries
	 * 
	 */

	public List<SBAccount> getAllSBAccountObjects() {
		List<SBAccount> SBAccountList= daoImpl.getAllSBAccountObjects();
		/*
		 * Iterator<SBAccount> iterator = SBAccountList.iterator();
		 * 
		 * while(iterator.hasNext()){
		 * 
		 * SBAccount sb = iterator.next();
		 * 
		 * System.out.println("Account Number: "+sb.getaccountnumber());
		 * System.out.println("Holder name: "+sb.getholdernamee());
		 * System.out.println(" Amount Outstanding: "+sb.balance); }
		 */

		return SBAccountList;
	}

	/**
	 * Method for retreive an entry for given accountno
	 * 
	 */
	public SBAccount getSBAccountByAccountno(int accountNo) 
	{
		SBAccount sb = daoImpl.getSBAccountByAccountno(accountNo);
		System.out.println("Account Number: "+sb.getaccountnumber());
		System.out.println("Holder name: "+sb.getholdernamee());
		System.out.println(" Outstanding Amount: "+sb.balance);

		return sb;
	}

	/**
	 * Method for deleting an entry for given accountno
	 * 
	 */

	public void deleteSBAccountObject(int accountNo) {
		daoImpl.deleteSBAccountObject(accountNo);
	}

	/**
	 * Method to sort the details of customer by name
	 */

	public List<SBAccount> getAllSBAccountObjectsSortByName()
	{
		List<SBAccount> sbAccountList= daoImpl.getAllSBAccountObjects();
		//Collections.sort(sbAccountList);

		Stream<SBAccount> stream=sbAccountList.stream();
		Stream<SBAccount> result=stream.sorted();
		List sorted=result.collect(Collectors.toList());

		Iterator<SBAccount> iterator= sorted.iterator();
		while(iterator.hasNext())
		{
			SBAccount fd = iterator.next();

			System.out.println("Account Number: "+fd.getaccountnumber());
			System.out.println("Holder name: "+fd.getholdernamee());
			System.out.println("Balance: "+fd.balance);
		}

		return sbAccountList;

	}

	/**
	 * Method to sort the details of customer by amount
	 */

	public List<SBAccount> getAllSBAccountObjectsSortByBalance()
	{
		List<SBAccount> sbAccountList= daoImpl.getAllSBAccountObjects();
		//Collections.sort(sbAccountList, new SBAccount());

		Stream<SBAccount> stream=sbAccountList.stream();
		Stream<SBAccount> result=stream.sorted(new SBAccount());
		List sorted=result.collect(Collectors.toList());

		Iterator<SBAccount> iterator= sorted.iterator();
		while(iterator.hasNext())
		{
			SBAccount fd = iterator.next();

			System.out.println("Account Number: "+fd.getaccountnumber());
			System.out.println("Holder name: "+fd.getholdernamee());
			System.out.println("Balance" +fd.balance);

		}

		return sbAccountList;


	}

	/**
	 * Method to add a new entry
	 */

	public void addSBAccount(SBAccount sbAccount)
	{
		boolean isAdded=daoImpl.addSBAccountObject(sbAccount);

		if(!isAdded) {
			System.out.println("Already exist");
		}
		else
			System.out.println("Added");
	}
	/**
	 * Method to update an entry
	 */

	public void updateLoanAccount(SBAccount sbAccount)
	{
		daoImpl.updateSBAccountObject(sbAccount);
	}

	/** Withdraw money method is for withdrawing money from account
	 * @throws InsufficientBalanceException */
	public float withdrawMoney(float amount) 
	{
		SBAccount account= new SBAccount();
		try {
			float result= account.withdrawMoney(amount);

			System.out.println("New Balance: "+result );
			return result;
		} catch (InsufficientBalanceException e) {
			System.out.println("Insufficient balance. your acccount balance is: "+account.balance);
			return account.balance;
		}

	}
}
