/**
 *CurrentAccountService
 *
 *This is the service class for CurrentAccount
 *
 *06/10/2020
 *
 */
package com.training.ust.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;

import com.training.ustjava.CurrentAccount;
import com.training.ustjava.FDAccount;
import com.ust.java.dataaccess.CurrentAccountDAO;
import com.ust.java.dataaccess.CuurentAccountDAOImpl;

public class CurrentAccountService {

	@Autowired
	CurrentAccountDAO daoImpl;

	public CurrentAccountService() {

		daoImpl=new CuurentAccountDAOImpl() ;
	}
	
	/**
	 * Method to get all the customer details
	 * 
	 */
	
	public List<CurrentAccount> getAllCurrentAccountObjects() {
		List<CurrentAccount> CurrentAccountList= daoImpl.getAllCurrentAccountObjects();
		/*
		 * Iterator<CurrentAccount> iterator = CurrentAccountList.iterator();
		 * 
		 * while(iterator.hasNext()){
		 * 
		 * CurrentAccount ca = iterator.next();
		 * 
		 * System.out.println("Account Number: "+ca.getaccountnumber());
		 * System.out.println("Holder name: "+ca.getholdernamee());
		 * System.out.println("Overdraft Amount: "+ca.OverDraftLimit);
		 */
		//}

		return CurrentAccountList;
	}
	
	/**
	 * Method to retrive the details of one coustomer for given account no
	 */

	public CurrentAccount getCurrentAccountByAccountno(int accountNo) 
	{
		CurrentAccount ca = daoImpl.getCurrentAccountByAccountno(accountNo);
		System.out.println("Account Number: "+ca.getaccountnumber());
		System.out.println("Holder name: "+ca.getholdernamee());
		System.out.println("Overdraft Amount: "+ca.OverDraftLimit);

		return ca;
	}
	
	/**
	 * Method to delete one entry for given account no
	 */
	
	public void deleteCurrentAccountObject(int accountNo) {
		daoImpl.deleteCurrentAccountObject(accountNo);
	}

	/**
	 * Method to sort the details of customer by name
	 */

	public List<CurrentAccount> getAllCurrentAccountObjectsSortByName()
	{
		List<CurrentAccount> currentAccountList= daoImpl.getAllCurrentAccountObjects();
		Collections.sort(currentAccountList);

		Iterator<CurrentAccount> iterator= currentAccountList.iterator();
		while(iterator.hasNext())
		{
			CurrentAccount ca = iterator.next();

			System.out.println("Account Number: "+ca.getaccountnumber());
			System.out.println("Holder name: "+ca.getholdernamee());
			System.out.println("OverDraftLimit: "+ca.OverDraftLimit);

		}

		return currentAccountList;

	}

	/**
	 * Method to sort the details of customer by amount
	 */

	public List<CurrentAccount> getAllFDAccountObjectsSortByOverDraftAmount()
	{
		List<CurrentAccount> currentAccountList= daoImpl.getAllCurrentAccountObjects();
		Collections.sort(currentAccountList, new CurrentAccount());

		Iterator<CurrentAccount> iterator= currentAccountList.iterator();
		while(iterator.hasNext())
		{
			CurrentAccount ca = iterator.next();

			System.out.println("Account Number: "+ca.getaccountnumber());
			System.out.println("Holder name: "+ca.getholdernamee());
			System.out.println("OverDraftLimit: "+ca.OverDraftLimit);

		}

		return currentAccountList;

	}
	
	/**
	 * Method to add a new entry
	 */

	public void addCurrentAccount(CurrentAccount currentAccount)
	{
		boolean isAdded=daoImpl.addCurrentAccountObject(currentAccount);

		if(!isAdded) {
			System.out.println("Already exist");
		}
		else
			System.out.println("Added");
	}
	/**
	 * Method to update an entry
	 */

	public void updateCurrentAccount(CurrentAccount currentAccount)
	{
		daoImpl.updateCurrentAccountObject(currentAccount);
	}

}
