/**
 * 
 * SBAccountController
 * 
 * Controller class for SBAccountDAOImpl
 * 
 * 15-10-2020
 */

package com.training.ust.controller;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import com.training.ust.service.SBAccountService;
import com.training.ustjava.SBAccount;

@Controller
public class SBAccountController {

	@Autowired
	private SBAccountService service;


	@RequestMapping("/sb")

	/**
	 * To retrieve all SBAccount objects and display the  details of each SBAccount
	 */

	public String getAllSbAccount(Model model){

		System.out.println("Inside controller getAllSbAccount");
		List<SBAccount> sb = service.getAllSBAccountObjects();
		model.addAttribute("key",sb );
		return "sbAccountList";

	}
}
