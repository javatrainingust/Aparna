/**
 *AboutMeController
 *
 * Controller class
 * 
 * 14-10-2020
 */

package com.ust.java.spring;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class AboutMeController {

	/**
	 * Method public String getMyHobbies() using @RequestMapping("/hobbies") and return the string "hobbies"
	 */
	@RequestMapping("/hobbies")
	public String getMyHobbies()
	{
		return "hobbies";
	}

}
