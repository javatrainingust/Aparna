/**
 * Instrument
 * 
 * This interface is created with an abstract method play
 *  
 * 12-10-2020
 */

package com.ust.java.spring;

public interface Instrument {
	
	public void play();

}
