/**
 * 
 * Instrumentalist
 * 
 * This class implements the interface Performer
 *  
 * 12-10-2020
 *
 */

package com.ust.java.spring;

public class Instrumentalist implements Performer {

	Saxophone sax;
	
	/** 
	 * Getter method for sax
	 */
	public Saxophone getSax() {
		return sax;
	}
	
	/** 
	 * Setter method for sax
	 */
	public void setSax(Saxophone saxophone) {
		sax = saxophone;
	}
	
	/**
	 * Implementation of method in Performer Interface
	 * @throws Exception 
	 */

	public void perform()  {

		sax=new Saxophone();
		sax.play();
		System.out.println("Song is sung");
	}

}
