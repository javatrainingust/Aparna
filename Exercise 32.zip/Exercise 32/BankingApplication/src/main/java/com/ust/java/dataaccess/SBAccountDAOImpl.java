package com.ust.java.dataaccess;

/**
 * 
 *SBAccountDAOImpl is the implementation class for SBAccountDAO
 * 
 *06-10-2020
 */

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import org.springframework.stereotype.Repository;
import com.training.ustjava.SBAccount;

@Repository
public class SBAccountDAOImpl implements SBAccountDAO{

	//Creating a list and inserting the values into it
	List<SBAccount> SBAccountList;
	Set<SBAccount> sbAccountSet;

	public SBAccountDAOImpl() {

		SBAccountList= new ArrayList<SBAccount>();
		sbAccountSet=new HashSet<SBAccount>();

		SBAccount fd1= new SBAccount(1000, "Aparna",2000); SBAccount fd2= new
				SBAccount(1001, "Arun", 4000); SBAccount fd3= new SBAccount(1002, "Anna",
						6000); SBAccount fd4= new SBAccount(1003, "Minu", 6000); SBAccount fd5= new
						SBAccount(1004, "Delna", 8000);

						SBAccountList.add(fd1); SBAccountList.add(fd2); SBAccountList.add(fd3);
						SBAccountList.add(fd4); SBAccountList.add(fd5);

	}

	/**
	 * Method to get all SBAccount
	 */
	public List<SBAccount> getAllSBAccountObjects() {
		return SBAccountList;
	}

	/**
	 * Method to get SBAccount by Account no
	 */

	public SBAccount getSBAccountByAccountno(int AccountNo) {
		SBAccount sbAccount=null;

		Iterator<SBAccount> iterator=SBAccountList.iterator();
		while(iterator.hasNext())
		{
			SBAccount fd=iterator.next();
			if(fd.getaccountnumber()==AccountNo)
				sbAccount=fd;

		}
		return sbAccount;
	}

	/**
	 * Method to delete SBAccount by Account no
	 */

	public void deleteSBAccountObject(int AccountNo) {

		for(int i=0; i< SBAccountList.size(); i++){
			SBAccount sb =(SBAccount)SBAccountList.get(i);
			if(sb.getaccountnumber()==AccountNo)
			{
				SBAccountList.remove(i);
			}

		}
	}

	/**
	 * 
	 * Method to add a new entry
	 */

	public boolean addSBAccountObject(SBAccount fd)
	{

		boolean isAdded=sbAccountSet.add(fd);
		if(isAdded)
		{
			SBAccountList.add(fd);
		}
		return isAdded;
	}
	/**
	 * Method to update an entry

	 */

	public void updateSBAccountObject(SBAccount sbccount)
	{
		Iterator iterator= SBAccountList.iterator();

		while(iterator.hasNext())
		{
			SBAccount fd= (SBAccount)iterator.next();
			if(fd.getaccountnumber()==sbccount.getaccountnumber())
			{
				fd.setholdername(sbccount.getholdernamee());
				fd.setaccountnumber(sbccount.getaccountnumber());
			}

		}

	}

}
