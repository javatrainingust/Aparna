package com.training.ustjava;

import static org.junit.jupiter.api.Assertions.*;
import java.util.*;

import org.junit.jupiter.api.Test;

import com.ust.java.dataaccess.LoanAccountDAO;
import com.ust.java.dataaccess.LoanAccountDAOImpl;

class LoanAccountDAOImplTest {

	List<LoanAccount> LoanAccountList;
	LoanAccountDAO accountDAO;

	public LoanAccountDAOImplTest()
	{
		accountDAO = new LoanAccountDAOImpl();
	}

	@Test
	void getAllLoanAccountObjectsTest() {
		int count = accountDAO.getAllLoanAccountObjects().size();
		assertEquals(5,count);
	}

	@Test
	void getLoanAccountByAccountnoTest() {
		LoanAccount account = accountDAO.getLoanAccountByAccountno(1000);
		assertEquals("Aparna",account.getholdernamee());
	}

	@Test
	void deleteLoanAccountObjectTest() {
		accountDAO.deleteLoanAccountObject(1000);
		int count = accountDAO.getAllLoanAccountObjects().size();
		assertEquals(4,count);
	}

}


