/**
 * 
 * MainSort
 * 
 * Main method to print the sorted details of customers
 * 
 * 07/10/2020
 * 
 */

package com.training.ustjava;

import com.training.ust.service.CurrentAccountService;
import com.training.ust.service.FDAccountService;
import com.training.ust.service.LoanAccountService;
import com.training.ust.service.SBAccountService;

public class MainSort {

	public static void main(String[] args) {



		/*
		 * FDAccountService service= new FDAccountService();
		 * System.out.println("Printing before sorting"); System.out.println();
		 * System.out.println(service.getAllFDaccountObjects());
		 * System.out.println("-------------------------------------------------");
		 * 
		 * System.out.println("Printing after sorting by name"); System.out.println();
		 * System.out.println(service.getAllFDAccountObjectsSortByName());
		 * System.out.println("-------------------------------------------------");
		 * 
		 * 
		 * System.out.println("Printing after sorting by amount"); System.out.println();
		 * System.out.println(service.getAllFDAccountObjectsSortByAmount());
		 * System.out.println("-------------------------------------------------");
		 */




		/*
		 * CurrentAccountService service= new CurrentAccountService();
		 * System.out.println("Printing before sorting"); System.out.println();
		 * System.out.println(service.getAllCurrentAccountObjects());
		 * System.out.println("-------------------------------------------------");
		 * 
		 * System.out.println("Printing after sorting by name"); System.out.println();
		 * System.out.println(service.getAllCurrentAccountObjectsSortByName());
		 * System.out.println("-------------------------------------------------");
		 * 
		 * System.out.println("Printing after sorting by amount"); System.out.println();
		 * System.out.println(service.getAllFDAccountObjectsSortByOverDraftAmount());
		 * System.out.println("-------------------------------------------------");
		 */






		
		  SBAccountService service1= new SBAccountService();
		  System.out.println("Printing before sorting"); System.out.println();
		  System.out.println(service1.getAllSBAccountObjects());
		  System.out.println("-------------------------------------------------");
		  
		  System.out.println("Printing after sorting by name"); System.out.println();
		  System.out.println(service1.getAllSBAccountObjectsSortByName());
		  System.out.println("-------------------------------------------------");
		  
		  System.out.println("Printing after sorting by balance");
		  System.out.println();
		  System.out.println(service1.getAllSBAccountObjectsSortByBalance());
		  System.out.println("-------------------------------------------------");
		 





		/*
		 * LoanAccountService service2= new LoanAccountService();
		 * System.out.println("Printing before sorting"); System.out.println();
		 * System.out.println(service2.getAllLoanAccountObjects());
		 * System.out.println("-------------------------------------------------");
		 * 
		 * System.out.println("Printing after sorting by name"); System.out.println();
		 * System.out.println(service2.getAllLoanAccountObjectsSortByName());
		 * System.out.println("-------------------------------------------------");
		 * 
		 * System.out.println("Printing after sorting by balance");
		 * System.out.println();
		 * System.out.println(service2.getAllLoanAccountObjectsSortByBalance());
		 * System.out.println("-------------------------------------------------");
		 */

	}

}
