/*
 * package com.training.ustjava;
 * 
 * import static org.junit.jupiter.api.Assertions.*;
 * 
 * import org.junit.jupiter.api.Test;
 * 
 * public class FDAccountTest {
 * 
 * @Test public void test() {
 * 
 * Boolean expectedValue= true; FDAccount ca= new FDAccount(); Boolean
 * actualValue=ca.updateautoRenewal(); assertEquals(expectedValue,actualValue);
 * 
 * }
 * 
 * }
 */