package com.training.ustjava;

import com.training.ust.service.CurrentAccountService;
import com.training.ust.service.FDAccountService;
import com.training.ust.service.LoanAccountService;
import com.training.ust.service.SBAccountService;

public class MainAddUpdate {

	public static void main(String[] args) {

		/*CurrentAccountService service = new CurrentAccountService();
		 * service.addCurrentAccount(new CurrentAccount(1001, "Anu", 50000));
		 * service.addCurrentAccount(new CurrentAccount(1001, "Anu", 50000));
		 * service.addCurrentAccount(new CurrentAccount(1002, "Aparna", 80000));
		 * System.out.println("Printing all details");
		 * service.getAllCurrentAccountObjects();
		 * System.out.println("---------------------------------------------");
		 * service.updateCurrentAccount(new CurrentAccount(1002, "Anu", 30000));
		 * System.out.println("Printing all updated details");
		 * service.getAllCurrentAccountObjects();
		 */
		
		/*
		 * FDAccountService service= new FDAccountService(); service.addFDAccount(new
		 * FDAccount(1001, "Anu", 50000,1000)); service.addFDAccount(new FDAccount(1002,
		 * "Minu", 50000,10)); service.addFDAccount(new FDAccount(1002, "Minu",
		 * 50000,3000)); System.out.println("Printing all details");
		 * service.getAllFDaccountObjects();
		 * System.out.println("---------------------------------------------");
		 * service.updateFDAccount(new FDAccount(1001, "Delna", 50000,10));
		 * System.out.println("Printing all updated details");
		 * service.getAllFDaccountObjects();
		 */
		
		/*
		 * LoanAccountService service= new LoanAccountService();
		 * service.addLoanAccount(new LoanAccount(1001, "Albert", 50000));
		 * service.addLoanAccount(new LoanAccount(1001, "Albert",1000));
		 * service.addLoanAccount(new LoanAccount(1002, "Kumar",1000));
		 * System.out.println("Printing all details");
		 * service.getAllLoanAccountObjects();
		 * System.out.println("---------------------------------------------");
		 * service.updateLoanAccount(new LoanAccount(1002, "Kia",1000));
		 * System.out.println("Printing all updated details");
		 * service.getAllLoanAccountObjects();
		 */
		
		SBAccountService service= new SBAccountService();
		service.addSBAccount(new SBAccount(1000, "Manoj",9000));
		service.addSBAccount(new SBAccount(1000, "Manoj",9000));
		service.addSBAccount(new SBAccount(1001, "Shani",9000));
		System.out.println("Printing all details");
		service.getAllSBAccountObjects();
		System.out.println("---------------------------------------------");	
		service.updateLoanAccount(new SBAccount(1001,"Piyush", 3000));
		System.out.println("Printing all updated details");	
		service.getAllSBAccountObjects();
	}

}
