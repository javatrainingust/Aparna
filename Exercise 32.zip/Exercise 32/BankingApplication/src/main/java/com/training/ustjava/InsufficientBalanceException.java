/**
 * InsufficientBalanceException
 * 
 * This class is user defined exception class.
 * 
 * Date: 06/10/2020
 */


package com.training.ustjava;

public class InsufficientBalanceException extends Exception {
	float amount;

	public InsufficientBalanceException(float amountToWithdraw) {
		this.amount=amount;
	}



	/**
	 * overrided toString method. 
	 * 
	 * */
	@Override
	public String toString() {
		return "You don't have enough amount to take "+this.amount +" rupees";
	}


}

