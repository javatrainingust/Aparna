package com.ust.java.dataaccess;

/**
 * 
 *LoanAccountDAO is the interface with the specified 3 methods
 *
 *06-10-2020
 */

import java.util.List;

import com.training.ustjava.FDAccount;
import com.training.ustjava.LoanAccount;

public interface LoanAccountDAO {
	
	public List<LoanAccount> getAllLoanAccountObjects();
	public LoanAccount getLoanAccountByAccountno(int accountNo);
	public void deleteLoanAccountObject(int accountNo);

}
