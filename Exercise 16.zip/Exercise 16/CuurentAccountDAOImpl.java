package com.ust.java.dataaccess;

/**
 * 
 *CurrentAccountDAOImpl is the implementation class forCurrentAccountDAO
 * 
 *06-10-2020
 */

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import com.training.ustjava.CurrentAccount;

public class CuurentAccountDAOImpl implements CurrentAccountDAO {
	
	List <CurrentAccount> CurrentAccountList;
	
	public CuurentAccountDAOImpl()
	{
		CurrentAccountList= new ArrayList<CurrentAccount>();
		CurrentAccount ca1= new CurrentAccount(1000, "Aparna", 20000);
		CurrentAccount ca2= new CurrentAccount(1001, "Anu", 50000);
		CurrentAccount ca3= new CurrentAccount(1002, "Ravi", 40000);
		CurrentAccount ca4= new CurrentAccount(1003, "Karthi",80000);
		CurrentAccount ca5= new CurrentAccount(1004, "Anju", 4000);
		
		CurrentAccountList.add(ca1);
		CurrentAccountList.add(ca2);
		CurrentAccountList.add(ca3);
		CurrentAccountList.add(ca4);
		CurrentAccountList.add(ca5);
		}

	@Override
	public List<CurrentAccount> getAllCurrentAccountObjects() {
		return CurrentAccountList;
	}

	@Override
	public CurrentAccount getCurrentAccountByAccountno(int accountNo) {
		CurrentAccount currentaccount=null;

		Iterator<CurrentAccount> iterator= CurrentAccountList.iterator();
		while(iterator.hasNext())
		{
			CurrentAccount ca= iterator.next();
			if(ca.getaccountnumber()==accountNo)
			currentaccount=ca;
		}
		
		return currentaccount;
	}

	@Override
	public void deleteCurrentAccountObject(int accountNo) {
		 for( int i=0; i<CurrentAccountList.size();i++)
		 {
			 CurrentAccount ca= CurrentAccountList.get(i);
			 if(ca.getaccountnumber()==accountNo)
			 {
				 CurrentAccountList.remove(i);
			 }
		 }

	}

}
