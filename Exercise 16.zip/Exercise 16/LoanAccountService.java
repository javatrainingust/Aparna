package com.training.ust.service;
/**
 * 
 *This is the service class for Loan Account
 * 
 *06-10-2020
 */


import java.util.Iterator;
import java.util.List;

import com.training.ustjava.CurrentAccount;
import com.training.ustjava.LoanAccount;
import com.ust.java.dataaccess.CurrentAccountDAO;
import com.ust.java.dataaccess.CuurentAccountDAOImpl;
import com.ust.java.dataaccess.LoanAccountDAO;
import com.ust.java.dataaccess.LoanAccountDAOImpl;

public class LoanAccountService {

	LoanAccountDAO daoImpl;

	public LoanAccountService() {

		daoImpl=new LoanAccountDAOImpl() ;
	}

	public List<LoanAccount> getAllLoanAccountObjects() {
		List<LoanAccount> LoanAccountList= daoImpl.getAllLoanAccountObjects();
		Iterator<LoanAccount>  iterator = LoanAccountList.iterator();

		while(iterator.hasNext()){

			LoanAccount la = iterator.next();

			System.out.println("Account Number: "+la.getaccountnumber());
			System.out.println("Holder name: "+la.getholdernamee());
			System.out.println("Loan Amount Outstanding: "+la.loanOutstanding);
		}

		return LoanAccountList;
	}


	public LoanAccount getLoanAccountByAccountno(int accountNo) 
	{
		LoanAccount la = daoImpl.getLoanAccountByAccountno(accountNo);
		System.out.println("Account Number: "+la.getaccountnumber());
		System.out.println("Holder name: "+la.getholdernamee());
		System.out.println("Loan Outstanding Amount: "+la.loanOutstanding);

		return la;
	}

	public void deleteCurrentAccountObject(int accountNo) {
		daoImpl.deleteLoanAccountObject(accountNo);
	}

}
