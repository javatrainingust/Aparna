package com.training.ustjava;

/**
 * 
 *Current Account is the extended class of base class Account containing variables and constructors
 *
 *30-09-2020
 */

public class CurrentAccount extends Account {

	public float OverDraftLimit;

	/*
	 * public String CheckOverDraft(int Balance) { String str; if(Balance>=50000)
	 * str="Overdraft limit is 25000 as balance above 50000";
	 * 
	 * else if(Balance >25000 && Balance <50000)
	 * str="Overdraft limit is 15000 as balance between 25k and 50k";
	 * 
	 * else str="Overdraft limit is 5000 as balance is below 25k"; return str; }
	 */


	public CurrentAccount(int accountNo, String holderName, float overDraftLimit) {
		super(accountNo,holderName);
		OverDraftLimit = overDraftLimit;
	}
}
