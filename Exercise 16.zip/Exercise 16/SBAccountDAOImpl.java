package com.ust.java.dataaccess;

/**
 * 
 *SBAccountDAOImpl is the implementation class for SBAccountDAO
 * 
 *06-10-2020
 */

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import com.training.ustjava.FDAccount;
import com.training.ustjava.SBAccount;

public class SBAccountDAOImpl implements SBAccountDAO{

	List<SBAccount> SBAccountList;

	public SBAccountDAOImpl() {

		SBAccountList= new ArrayList<SBAccount>();
		SBAccount fd1= new SBAccount(1000, "Aparna",2000);
		SBAccount fd2= new SBAccount(1001, "Arun", 4000);
		SBAccount fd3= new SBAccount(1002, "Anna", 6000);
		SBAccount fd4= new SBAccount(1003, "Minu", 6000);
		SBAccount fd5= new SBAccount(1004, "Delna", 8000);

		SBAccountList.add(fd1);
		SBAccountList.add(fd2);
		SBAccountList.add(fd3);
		SBAccountList.add(fd4);
		SBAccountList.add(fd5);
	}


	public List<SBAccount> getAllSBAccountObjects() {
		return SBAccountList;
	}


	public SBAccount getSBAccountByAccountno(int AccountNo) {
		SBAccount sbAccount=null;

		Iterator<SBAccount> iterator=SBAccountList.iterator();
		while(iterator.hasNext())
		{
			SBAccount fd=iterator.next();
			if(fd.getaccountnumber()==AccountNo)
				sbAccount=fd;

		}
		return sbAccount;
	}


	public void deleteSBAccountObject(int AccountNo) {

		for(int i=0; i< SBAccountList.size(); i++){
			SBAccount sb =(SBAccount)SBAccountList.get(i);
			if(sb.getaccountnumber()==AccountNo)
			{
				SBAccountList.remove(i);
			}

		}
	}

}
