package com.training.ustjava;

/**
 * 
 *Account is the base class containing variables accountno and holdername and constructors
 *
 *30-09-2020
 */

public class Account {

	public Account() {
	}
	
	public Account(int accountNo, String holderName) {

		//System.out.println("Inside Base Class arg constructor " +accountNo +" "+holderName); 
		this.accountNo=accountNo; 
		this.holderName=holderName; 
	}

	private int accountNo;
	private String holderName;

	public int getaccountnumber() {
		return accountNo;
	}
	public void setaccountnumber(int accountnumber) {
		this.accountNo = accountnumber;
	}
	public String getholdernamee() {
		return holderName;
	}
	public void setholdername(String holdername) {
		this.holderName = holdername;
	}
}