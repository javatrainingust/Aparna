package com.training.ust.service;
/**
 * 
 *This is the service class for FD Account
 * 
 *06-10-2020
 */

import java.util.Iterator;
import java.util.List;

import com.training.ustjava.FDAccount;
import com.ust.java.dataaccess.FDAccountDAO;
import com.ust.java.dataaccess.FDAccountDAOImpl;

public class FDAccountService {

	FDAccountDAO daoImpl;

	public FDAccountService()
	{
		daoImpl= new FDAccountDAOImpl();
	}

	public List<FDAccount> getAllFDaccountObjects() {
		List<FDAccount> FDAccountList= daoImpl.getAllFDAccountObjects();
		Iterator<FDAccount>  iterator = FDAccountList.iterator();

		while(iterator.hasNext()){

			FDAccount fd = iterator.next();

			System.out.println("Account Number: "+fd.getaccountnumber());
			System.out.println("Holder name: "+fd.getholdernamee());
			System.out.println("Amount: "+fd.amount);
			System.out.println("Duration: "+fd.duration);
		}

		return FDAccountList;
	}


	public FDAccount getFDAccountByAccountno(int accountnumber) {
		FDAccount fd = daoImpl.getFDAccountByAccountno(accountnumber);
		System.out.println("Account Number: "+fd.getaccountnumber());
		System.out.println("Holder name: "+fd.getholdernamee());
		System.out.println("Amount: "+fd.amount);
		System.out.println("Duration: "+fd.duration);
		return fd;
	}
	public void deleteFDAccountObject(int accountnumber) {
		daoImpl.deleteFDAccountObject(accountnumber);
	}
}
