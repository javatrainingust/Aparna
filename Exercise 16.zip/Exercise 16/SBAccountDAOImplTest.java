package com.training.ustjava;

import static org.junit.jupiter.api.Assertions.*;
import java.util.*;
import org.junit.jupiter.api.Test;

import com.ust.java.dataaccess.SBAccountDAO;
import com.ust.java.dataaccess.SBAccountDAOImpl;

class SBAccountDAOImplTest {

	List<SBAccount> SBAccountList;
	SBAccountDAO accountDAO;

	public SBAccountDAOImplTest()
	{
		accountDAO = new SBAccountDAOImpl();
	}

	@Test
	void getAllSBAccountObjectsTest() {
		int count = accountDAO.getAllSBAccountObjects().size();
		assertEquals(5,count);
	}

	@Test
	void getSBAccountByAccountnoTest() {
		SBAccount account = accountDAO.getSBAccountByAccountno(1000);
		assertEquals("Aparna",account.getholdernamee());
	}

	@Test
	void deleteSBAccountObjectTest() {
		accountDAO.deleteSBAccountObject(1000);
		int count = accountDAO.getAllSBAccountObjects().size();
		assertEquals(4,count);
	}
}


