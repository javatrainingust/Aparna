package com.training.ust.service;
/**
 * 
 *This is the service class for SB Account
 * 
 *06-10-2020
 */


import java.util.Iterator;
import java.util.List;

import com.training.ustjava.LoanAccount;
import com.training.ustjava.SBAccount;
import com.ust.java.dataaccess.LoanAccountDAO;
import com.ust.java.dataaccess.LoanAccountDAOImpl;
import com.ust.java.dataaccess.SBAccountDAO;
import com.ust.java.dataaccess.SBAccountDAOImpl;

public class SBAccountService {
	
	SBAccountDAO daoImpl;

	public SBAccountService() {

		daoImpl=new SBAccountDAOImpl() ;
	}

	public List<SBAccount> getAllSBAccountObjects() {
		List<SBAccount> SBAccountList= daoImpl.getAllSBAccountObjects();
		Iterator<SBAccount>  iterator = SBAccountList.iterator();

		while(iterator.hasNext()){

			SBAccount sb = iterator.next();

			System.out.println("Account Number: "+sb.getaccountnumber());
			System.out.println("Holder name: "+sb.getholdernamee());
			System.out.println(" Amount Outstanding: "+sb.balance);
		}

		return SBAccountList;
	}


	public SBAccount getSBAccountByAccountno(int accountNo) 
	{
		SBAccount sb = daoImpl.getSBAccountByAccountno(accountNo);
		System.out.println("Account Number: "+sb.getaccountnumber());
		System.out.println("Holder name: "+sb.getholdernamee());
		System.out.println(" Outstanding Amount: "+sb.balance);

		return sb;
	}

	public void deleteSBAccountObject(int accountNo) {
		daoImpl.deleteSBAccountObject(accountNo);
	}

}
