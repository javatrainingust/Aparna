package com.training.ust.service;
/**
 * 
 *This is the service class for Current Account
 * 
 *06-10-2020
 */


import java.util.Iterator;
import java.util.List;

import com.training.ustjava.CurrentAccount;
import com.training.ustjava.FDAccount;
import com.ust.java.dataaccess.CurrentAccountDAO;
import com.ust.java.dataaccess.CuurentAccountDAOImpl;

public class CurrentAccountService {
	
	CurrentAccountDAO daoImpl;
	
	public CurrentAccountService() {
		
		daoImpl=new CuurentAccountDAOImpl() ;
	}
	
	public List<CurrentAccount> getAllCurrentAccountObjects() {
		List<CurrentAccount> CurrentAccountList= daoImpl.getAllCurrentAccountObjects();
		Iterator<CurrentAccount>  iterator = CurrentAccountList.iterator();

		while(iterator.hasNext()){

			CurrentAccount ca = iterator.next();

			System.out.println("Account Number: "+ca.getaccountnumber());
			System.out.println("Holder name: "+ca.getholdernamee());
			System.out.println("Overdraft Amount: "+ca.OverDraftLimit);
		}

		return CurrentAccountList;
	}


	public CurrentAccount getCurrentAccountByAccountno(int accountNo) 
	{
		CurrentAccount ca = daoImpl.getCurrentAccountByAccountno(accountNo);
		System.out.println("Account Number: "+ca.getaccountnumber());
		System.out.println("Holder name: "+ca.getholdernamee());
		System.out.println("Overdraft Amount: "+ca.OverDraftLimit);
	
		return ca;
	}
	
	public void deleteCurrentAccountObject(int accountNo) {
		daoImpl.deleteCurrentAccountObject(accountNo);
	}
	

}
