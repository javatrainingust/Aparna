package com.training.ustjava;
/**
 * 
 *SBAccount is the extended class of base class Account containing variables and constructors
 *
 *30-09-2020
 */

public class SBAccount extends Account {

	public float balance;

	public SBAccount(int accoutNo, String holderName, float balance) {
		super(accoutNo, holderName);
		this.balance = balance;
	}
}
	
	
	
	
	/*//float duration=1;
	//InterestCalculator ic= new InterestCalculator();

	public float getbalance() {
		return balance;
	}
	

  public float withdrawMoney(float amountWithdrawn) { balance=balance-
  amountWithdrawn; return balance;
  
  } }
  
  
  public void calculateInterest(float amount,ICalculator calculator){
  
  float sbinterest=calculator.interestCalculation( amount,duration);
  System.out.println(sbinterest); }
  
  
  
  
  } public void CalculateInterest() { this.ic.SavingsAccountInterest(30000, 1);
  }
 */
 

