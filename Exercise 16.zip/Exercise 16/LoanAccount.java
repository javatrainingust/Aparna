package com.training.ustjava;

/**
 * 
 *LoanAccount is the extended class of base class Account containing variables and constructors
 *
 *30-09-2020
 */

public class LoanAccount extends Account{

	int tenure=12;
	public float loanOutstanding;
	
	public LoanAccount(int accountNo, String holderName, float loanOutstanding)
	{
		super(accountNo,holderName);
		this.loanOutstanding=loanOutstanding;
	}

	/*
	 * public void CalculateEmi(float loanTaken) { float emi= loanTaken/tenure;
	 * loanOutstanding=loanTaken-emi; System.out.println("Emi for loan amount "
	 * +loanTaken +" is: " +emi);
	 * System.out.println("Loan Outstanding Amount after emi remittance is: "
	 * +loanOutstanding); }
	 */

}
