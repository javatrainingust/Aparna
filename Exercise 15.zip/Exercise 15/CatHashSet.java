package com.ust.java.collections;

/**
 * This class is the base class if Cat1. 
 * Date: 05/10/2020
 */

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

public class CatHashSet {

	public static void main(String[] args) {
		
		/*Cat name and age is inserted using Hashset*/
		Set s= new HashSet<Cat1>();
		boolean b[]= new boolean[3];
		
		Cat1 cat1 = new Cat1("rosy",2);
		Cat1 cat2 = new Cat1("pinky",3);
		Cat1 cat3 = new Cat1("rosy",2);
		
		/* HashMap is used to created key value pair with key as owner name */
		Map map= new HashMap<Cat, String>();
		
		map.put(cat1, "Arjun");
		map.put(cat2, "Aparna");
		map.put(cat3, "Anu");
		
		/* Printing the value wrt key */
		System.out.println("Owner of Rosy cat is " +map.get(cat1));
		System.out.println("Owner of Pinky cat is " +map.get(cat2));
		System.out.println("Owner of " +map.get(cat3));;
		
		/*
		 * b[0]= s.add(cat1); b[1]=s.add(cat2); b[2]=s.add(cat3);
		 * 
		 * for( int i=0; i<b.length;i++) { System.out.println("Records are: " +b[i]); }
		 * 
		 * for (Object o: s) { System.out.println(" "+o); }
		 */
				
	}

}
