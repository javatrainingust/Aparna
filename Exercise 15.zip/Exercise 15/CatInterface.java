package com.ust.java.collections;

public interface CatInterface {
	
	public void sleep();

}
