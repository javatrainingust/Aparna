package com.ust.java.collections;

/**
 *This class is created to insert actor and film as key value pair and to print the respective film as key as actor name. 
 * Date: 05/10/2020
 */

import java.util.HashMap;
import java.util.Map;

public class HashMapDemo {

	public static void main(String[] args) {
		
		Map map= new HashMap<String, String>();
		
		map.put("PrabhuDeva", "ABCD");
		map.put("Mohanlal", "Chithram");
		map.put("Mamootty", "Valsalyam");
		
			System.out.println("The movie acted by Mohanlal is " +map.get("Mohanlal"));
		
	}

}
