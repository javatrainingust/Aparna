/*
 * BankingAppSpringBootApplicationTests
*
 * BankingAppSpringBootApplicationTests is a test class
 * 28-10-2020
 * */


package com.ust.training.BankingAppSpringBoot;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.when;
import java.util.ArrayList;
import java.util.List;
import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.boot.test.context.SpringBootTest;
import com.training.java.bankingapplicationmaster.dao.FDAccountDao;
import com.training.java.bankingapplicationmaster.model.FDAccount;
import com.training.java.bankingapplicationmaster.service.FDAccountService;

/*
 * Test class
 * */
@SpringBootTest
@RunWith(MockitoJUnitRunner.class)
class BankingAppSpringBootApplicationTests {

	/*Mocking the object*/
	@Mock
	private FDAccountDao fdAccountDaoMock;
	
	/*Mock Object will be injected whenever we use Dao*/
	
	@InjectMocks
	private FDAccountService fdAccountService;
	
	/*
	 * testGetEmployeesBasedOnBalance is a method for testing getEmployeesBasedOnBalance method.
	 * */
	
	@Test 
	  public void testGetEmployeesBasedOnBalance() {
		
		FDAccount fAccount1=new FDAccount();
		fAccount1.setBalance(10000);
		FDAccount fAccount2=new FDAccount();
		fAccount2.setBalance(2000);
		FDAccount fAccount3=new FDAccount();
		fAccount3.setBalance(50000);
		FDAccount fAccount4=new FDAccount();
		fAccount4.setBalance(180000);
		FDAccount fAccount5=new FDAccount();
		fAccount5.setBalance(500);
		
		List<FDAccount> fAccounts=new ArrayList<>();
		fAccounts.add(fAccount1);
		fAccounts.add(fAccount2);
		fAccounts.add(fAccount3);
		fAccounts.add(fAccount4);
		fAccounts.add(fAccount5);
		
		when(fdAccountDaoMock.getAllFDAccounts()).thenReturn(fAccounts);
		
		assertEquals(2, fdAccountService.getEmployeesBasedOnBalance(10000).size());
	}