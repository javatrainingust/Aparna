package com.training.ust.service;
/**
 * 
 *This is the main class for Loan Account
 * 
 *06-10-2020
 */

public class LoanAccountMain {

	public static void main(String[] args) {
		
		LoanAccountService loanservice= new LoanAccountService();

		loanservice.getAllLoanAccountObjects();
		System.out.println("-----------------------------------");
		loanservice.getLoanAccountByAccountno(1000);
		System.out.println("-----------------------------------");
		loanservice.deleteCurrentAccountObject(1002);
		System.out.println("-----------------------------------");
		loanservice.getAllLoanAccountObjects();

	}

}

