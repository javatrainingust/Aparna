/**
 *FDAccountController
 *
 *This is the controller class for FDAccount
 *
 *06/10/2020
 *
 */

package com.training.ust.controller;


import org.springframework.stereotype.Controller;
import com.training.ust.service.FDAccountService;
import com.training.ustjava.CurrentAccount;
import com.training.ustjava.FDAccount;
import com.training.ustjava.LoanAccount;

import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;

@Controller
public class FDAccountController {

	@Autowired
	private FDAccountService service;

	/**
	 * To show the details of all FDAccount objects
	 */


	@GetMapping("/showFd")

	public String showFDAccount(Model model) {

		FDAccount ca = new FDAccount();
		model.addAttribute("key", ca);
		return "addFd";

	}

	/**
	 * To add a FDAccount objects and display the  details of each FDAccount.
	 */

	@PostMapping("/addfdaccount")
	public String addCurrentAccountObject(@ModelAttribute("fdAccount") FDAccount ca1) {

		service.addFDAccount(ca1);
		return "redirect:/fd";

	}

	/**
	 * Method to update the details of a particular fd account holder
	 */

	@PutMapping("/updateFdAccount")
	public String updateFd(@ModelAttribute("fdAccount") FDAccount la) {

		service.updateFDAccount(la);
		return "redirect:/fd";
	}


	@GetMapping("/fd")
	/**
	 * To retrieve all FDAccount objects and display the  details of each FDAccount.
	 */
	public String getAllFdAccount(Model model){

		System.out.println("Inside controller getAllFdAccount");
		List<FDAccount> fd = service.getAllFDaccountObjects();
		model.addAttribute("key",fd );
		return "fdAccountList";

	}

	/**
	 * To retrieve and display the FDAccount objects of a specific Account holder
	 */

	@GetMapping("/specificfd")
	public String getSpecificFDAccount(@RequestParam("id") String id, Model model){

		FDAccount ca= service.getFDAccountByAccountno(Integer.parseInt(id));
		model.addAttribute("key1",ca );
		return "viewFdAccount";

	}

	/**
	 * To delete an account using accountno and to display the rest of FDAccount 
	 */

	@DeleteMapping("/deletefd")
	public String deleteSpecificFDtAccount(@RequestParam("id") String id, Model model){

		service.deleteFDAccountObject(Integer.parseInt(id));
		return "redirect:fd ";

	}

	/**
	 * To sort accounts using accountno and to display the details 
	 */

	@GetMapping("/sortFDAccountByName")

	public String getAllFdAccountsSortByName(Model model){
		System.out.println("Inside controller getAllAccountsSortByName");

		List<FDAccount> ca = service.getAllFDAccountObjectsSortByName();
		model.addAttribute("fdAccount",ca );
		return "fdAccountList";

	}

	/**
	 * To sort accounts using holder name and to display the details 
	 */

	@GetMapping("/sortFdAccountByName")

	public String getAllFdAccountsSortByName1(Model model){

		System.out.println("Inside controller getAllAccountsSortByName");
		List<FDAccount> ca = service.getAllFDAccountObjectsSortByName();
		model.addAttribute("fdAccount",ca );
		return "redirect:/fd";

	}

	/**
	 * To sort accounts using accountno and to display the details 
	 */

	@GetMapping("/sortFdAccountByAccountNo") 
	public String  getAllFdAccountsSortByAmount(Model model){

		List<FDAccount> ca = service.getAllFDAccountObjectsSortByAmount();
		model.addAttribute("fdAccount",ca );
		return "redirect:/fd";

	}

/*
	 * Method to getFDAccounts  details based on balance
	 */
	
	@GetMapping("/fdAccountsbalances/{balance}") 
	public List<FDAccount> getEmployeesBasedOnSalary(@PathVariable float balance){
		
		
		List<FDAccount> accountList = fdAccountService.getEmployeesBasedOnBalance(balance);
		
				
		return accountList;
		
	}

}



