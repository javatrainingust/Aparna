/**
 * 
 * SBAccountController
 * 
 * Controller class for SBAccountDAOImpl
 * 
 * 15-10-2020
 */

package com.training.ust.controller;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import com.training.ust.service.SBAccountService;
import com.training.ustjava.SBAccount;

//RestController annotation is used to create RESTful web services using Spring MVC
@RestController
public class SBAccountController {

	//Autowired annotation is used to create the object for service class
	@Autowired
	private SBAccountService service;

	/**
	 * Method to create a new SB Account
	 */
	@PostMapping("/sbaccounts")
	public SBAccount addSBAccount(@RequestBody SBAccount sb) {

		service.addSBAccount(sb);
		return sb;
	}

	/**
	 * Method to retrieve all SB Accounts
	 */
	@GetMapping("/sbaccounts")
	public List<SBAccount> getAllSBAccount() {

		//Getting all the details into the list
		List <SBAccount> sbList= service.getAllSBAccountObjects();
		return sbList;
	}

	/**
	 * Method to retrieve a specific SB Account using account number
	 */
	@GetMapping("/sbaccounts/{id}")
	public SBAccount getSpecificSBAccount(@PathVariable int id) {

		SBAccount sb= service.getSBAccountByAccountno(id);
		return sb;
	}

	/**
	 * Method to update a specific SB Account using account number
	 */
	@PutMapping("/sbaccounts/{id}")
	public SBAccount updateSBAccount(@PathVariable int id, @RequestBody SBAccount sb) {

		SBAccount sbAccount= service.getSBAccountByAccountno(id);
		//We need to update the details only if any field is changed
		if(sbAccount!=null)
		{
			service.updateLoanAccount(sb);
		}

		return sb;
	}

	/**
	 * Method to delete a specific SB Account using account number
	 */
	@DeleteMapping("/sbaccounts/{id}")
	public void deleteSBAccount(@PathVariable int id) {

		service.deleteSBAccountObject(id);	
	}
}











/**
 * To add a SBAccount objects and display the details of each SBAccount.
 */
/*
 * 
 * @RequestMapping("/addsbaccount") public String
 * addSbAccountObject(@ModelAttribute("sbAccount") SBAccount ca1) {
 * 
 * 
 * service.addSBAccount(ca1); return "redirect:/fd";
 * 
 * }
 * 
 *//**
 * Method to update the details of a particular account holder
 */
/*
 * 
 * @RequestMapping("/updateSbAccount") public String
 * updateSB(@ModelAttribute("sbAccount") SBAccount la) {
 * 
 * service.updateLoanAccount(la); return "redirect:/sb"; }
 * 
 * 
 * @RequestMapping("/sb")
 * 
 *//**
 * To retrieve all SBAccount objects and display the details of each SBAccount
 */
/*
 * 
 * public String getAllSbAccount(Model model){
 * 
 * System.out.println("Inside controller getAllSbAccount"); List<SBAccount> sb =
 * service.getAllSBAccountObjects(); model.addAttribute("key",sb ); return
 * "sbAccountList";
 * 
 * }
 * 
 *//**
 * To retrieve and display the SBAccount objects of a specific Account holder
 */
/*
 * 
 * @RequestMapping("/specificsb") public String
 * getSpecificSBAccount(@RequestParam("id") String id, Model model){
 * 
 * SBAccount ca= service.getSBAccountByAccountno(Integer.parseInt(id));
 * model.addAttribute("key1",ca ); return "viewSbAccount";
 * 
 * }
 * 
 *//**
 * To delete an account using accountno and to display the rest of SBAccount
 */
/*
 * 
 * @RequestMapping("/deletesb") public String
 * deleteSpecificSbAccount(@RequestParam("id") String id, Model model){
 * 
 * service.deleteSBAccountObject(Integer.parseInt(id)); return "redirect:sb ";
 * 
 * }
 * 
 *//**
 * To sort accounts using holder name and to display the details
 */
/*
 * 
 * @RequestMapping("/sortSbAccountByName")
 * 
 * public String getAllSBAccountsSortByName(Model model){
 * 
 * List<SBAccount> ca = service.getAllSBAccountObjectsSortByName();
 * model.addAttribute("sbAccount",ca ); return "redirect:/sb";
 * 
 * }
 * 
 *//**
 * To sort accounts using accountno and to display the details
 *//*
 * 
 * @RequestMapping("/sortSbAccountByAmount") public String
 * getAllSBAccountsSortByAccountNo(Model model){
 * 
 * List<SBAccount> ca = service.getAllSBAccountObjectsSortByBalance();
 * model.addAttribute("sbAccount",ca ); return "redirect:/sb";
 * 
 * }
 */

