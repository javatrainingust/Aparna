/***
	 * LoanAccountServiceTest 
	 * 
	 *  This is test class for LoanAccountService
	 * 
	 * 07-10-2020
	 * */

package com.training.ust.service;

import static org.junit.jupiter.api.Assertions.*;

import java.util.List;

import org.junit.jupiter.api.Test;

import com.training.ustjava.LoanAccount;

class LoanAccountServiceTest {

		/* for getting all accounts  sorted by names*/

		@Test
		public void testSortedByNames() {
			String expectedValue ="Anna";
			LoanAccountService  loanAccountService=new  LoanAccountService();
			List<LoanAccount> loanAccountServiceList=loanAccountService.getAllLoanAccountObjectsSortByName();
			String actualValue= loanAccountServiceList.get(0).getholdernamee();
			assertEquals(expectedValue,actualValue);
		}
		/* for getting all accounts  sorted by balance*/


		@Test public void testSortedByBalance() { 
			float expectedValue =2000;
			LoanAccountService loanAccountService=new LoanAccountService();
			List<LoanAccount>	loanAccountServiceList=loanAccountService.getAllLoanAccountObjectsSortByBalance();
			float actualValue=loanAccountServiceList.get(0).loanOutstanding;
			assertEquals(expectedValue,actualValue,0.0f); }


	}

