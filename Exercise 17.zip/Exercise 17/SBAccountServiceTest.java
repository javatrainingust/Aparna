/***
 * SBAccountServiceTest 
 * 
 *  This is test class for SBAccountService
 * 
 * 07-10-2020
 * */
package com.training.ust.service;

import static org.junit.jupiter.api.Assertions.*;

import java.util.List;

import org.junit.jupiter.api.Test;

import com.training.ustjava.SBAccount;

class SBAccountServiceTest {

	/* for getting all accounts  sorted by names*/

	@Test
	public void testSortedByNames() {
		String expectedValue ="Anna";
		SBAccountService  sbAccountService=new  SBAccountService();
		List<SBAccount> sbAccountServiceList=sbAccountService.getAllSBAccountObjectsSortByName();
		String actualValue= sbAccountServiceList.get(0).getholdernamee();
		assertEquals(expectedValue,actualValue);
	}
	/* for getting all accounts  sorted by balance*/


	@Test public void testSortedByBalance() { 
		float expectedValue =2000;
		SBAccountService sbAccountService=new SBAccountService();
		List<SBAccount>	sbAccountServiceList=sbAccountService.getAllSBAccountObjectsSortByBalance();
		float actualValue=sbAccountServiceList.get(0).balance;
		assertEquals(expectedValue,actualValue,0.0f); 
	}




}
