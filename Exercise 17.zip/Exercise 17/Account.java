/**
 * 
 * Account
 * 
 *This is the base class for FDAccount,SBAccount,LoanAccount and CurrentAccount
 *
 *30-09-2020
 */

package com.training.ustjava;

public class Account {

	//Non argument constructor
	public Account() {
	}

	//Parameterized constructor
	public Account(int accountNo, String holderName) {

		//System.out.println("Inside Base Class arg constructor " +accountNo +" "+holderName); 
		this.accountNo=accountNo; 
		this.holderName=holderName; 
	}
	/**
	 * Getter and Setter methods for the variables accountNo and hilderName
	 */

	private int accountNo;
	protected String holderName;

	public int getaccountnumber() {
		return accountNo;
	}
	public void setaccountnumber(int accountnumber) {
		this.accountNo = accountnumber;
	}
	public String getholdernamee() {
		return holderName;
	}
	public void setholdername(String holdername) {
		this.holderName = holdername;
	}
}