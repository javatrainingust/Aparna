/**
 * 
 *FDAccount
 * 
 *This is the child class of Account
 *
 *30-09-2020
 */

package com.training.ustjava;

import java.util.Comparator;

public class FDAccount extends Account implements Comparable<FDAccount>,Comparator<FDAccount>{

	//public int tenure=10;
	public float amount;
	public float duration;

	//Non arg constructor
	public FDAccount() {
	}

	//Parameterized constructor
	public FDAccount(int accountNo, String holderName,float amount, float duration) {
		super(accountNo, holderName);
		this.amount=amount;
		this.duration=duration;
	}
	/**
	 * Methods of Comparable and Comparator Interface
	 */
	@Override
	public int compareTo(FDAccount fd) {
		// TODO Auto-generated method stub
		return this.holderName.compareTo(fd.getholdernamee());
	}

	@Override
	public int compare(FDAccount o1, FDAccount o2) {
		// TODO Auto-generated method stub
		return (int) (o1.amount-o2.amount);
	}

	/*
	 * public boolean updateautoRenewal() {
	 * 
	 * boolean check = (tenure>5)?true:false;
	 * System.out.println("FD Account need auto renewal: " +check); return check;
	 * 
	 * }
	 */
}







/*	
	public void CalculateInterest(float amount, float duration)
	{
		double rate =0.7;
		double interst= (amount*duration*rate)/100;
		System.out.println("Fixed Accout interst for amount " +amount + " is:" +interst);
	}

}


public void CalculateInterest()
	{
		this.ic.FixedAccountInterest(30000, 1);
	}

	public void autorenewable(int tenure)
	{
		String maturitydate= "31/10/2020";
		DateFormat formatter = new SimpleDateFormat("dd/MM/yyyy");
		Date md= new Date();
		try {
			md = formatter.parse(maturitydate);
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		Date today = Calendar.getInstance().getTime();

		System.out.println(md);
		System.out.println(today);
		boolean check = (tenure>5)?true:false;
		System.out.println("FD Account need auto renewal: " +check);
		if(check && (md.before(today)|| md.equals(today)))
		{
			System.out.println("Auto renewal done");

		}
		else
			System.out.println("Auto renewal not done");

	}

}*/
