/***
 * CurrentAccountServiceTest 
 * 
 * This is test class for CurrentAccountService
 * 
 * 07-10-2020
 * */

package com.training.ust.service;

import static org.junit.jupiter.api.Assertions.*;
import java.util.List;
import org.junit.jupiter.api.Test;
import com.training.ustjava.CurrentAccount;

class CurrentAccountServiceTest {

	/* for getting all accounts  sorted by names*/

	@Test
	public void testSortedByNames() {
		String expectedValue ="Anju";
		CurrentAccountService  currentAccountService=new  CurrentAccountService();
		List<CurrentAccount> currentAccountServiceList=currentAccountService.getAllCurrentAccountObjectsSortByName();
		String actualValue= currentAccountServiceList.get(0).getholdernamee();
		assertEquals(expectedValue,actualValue);
	}
	/* for getting all accounts  sorted by balance*/


	@Test public void testSortedByBalance() { 
		float expectedValue =4000;
		CurrentAccountService currentAccountService=new CurrentAccountService();
		List<CurrentAccount>
		currentAccountServiceList=currentAccountService.getAllFDAccountObjectsSortByOverDraftAmount()
		; float actualValue=currentAccountServiceList.get(0).OverDraftLimit;
		assertEquals(expectedValue,actualValue,0.0f); }


}
