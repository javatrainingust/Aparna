/**
 *SBAccountService
 *
 *This is the service class for SBAccount
 *
 *06/10/2020
 *
 */

package com.training.ust.service;


import java.util.Collections;
import java.util.Iterator;
import java.util.List;

import com.training.ustjava.FDAccount;
import com.training.ustjava.LoanAccount;
import com.training.ustjava.SBAccount;
import com.ust.java.dataaccess.LoanAccountDAO;
import com.ust.java.dataaccess.LoanAccountDAOImpl;
import com.ust.java.dataaccess.SBAccountDAO;
import com.ust.java.dataaccess.SBAccountDAOImpl;

public class SBAccountService {
	
	SBAccountDAO daoImpl;

	public SBAccountService() {

		daoImpl=new SBAccountDAOImpl() ;
	}
	/**
	 * Method for printing all the enteries
	 * 
	 */

	public List<SBAccount> getAllSBAccountObjects() {
		List<SBAccount> SBAccountList= daoImpl.getAllSBAccountObjects();
		Iterator<SBAccount>  iterator = SBAccountList.iterator();

		while(iterator.hasNext()){

			SBAccount sb = iterator.next();

			System.out.println("Account Number: "+sb.getaccountnumber());
			System.out.println("Holder name: "+sb.getholdernamee());
			System.out.println(" Amount Outstanding: "+sb.balance);
		}

		return SBAccountList;
	}

	/**
	 * Method for retreive an entry for given accountno
	 * 
	 */
	public SBAccount getSBAccountByAccountno(int accountNo) 
	{
		SBAccount sb = daoImpl.getSBAccountByAccountno(accountNo);
		System.out.println("Account Number: "+sb.getaccountnumber());
		System.out.println("Holder name: "+sb.getholdernamee());
		System.out.println(" Outstanding Amount: "+sb.balance);

		return sb;
	}
	
	/**
	 * Method for deleting an entry for given accountno
	 * 
	 */

	public void deleteSBAccountObject(int accountNo) {
		daoImpl.deleteSBAccountObject(accountNo);
	}
	
	/**
	 * Method to sort the details of customer by name
	 */

	public List<SBAccount> getAllSBAccountObjectsSortByName()
	{
		List<SBAccount> sbAccountList= daoImpl.getAllSBAccountObjects();
		Collections.sort(sbAccountList);

		Iterator<SBAccount> iterator= sbAccountList.iterator();
		while(iterator.hasNext())
		{
			SBAccount fd = iterator.next();

			System.out.println("Account Number: "+fd.getaccountnumber());
			System.out.println("Holder name: "+fd.getholdernamee());
			System.out.println("Balance: "+fd.balance);
		}

		return sbAccountList;

	}

	/**
	 * Method to sort the details of customer by amount
	 */

	public List<SBAccount> getAllSBAccountObjectsSortByBalance()
	{
		List<SBAccount> sbAccountList= daoImpl.getAllSBAccountObjects();
		Collections.sort(sbAccountList, new SBAccount());

		Iterator<SBAccount> iterator= sbAccountList.iterator();
		while(iterator.hasNext())
		{
			SBAccount fd = iterator.next();

			System.out.println("Account Number: "+fd.getaccountnumber());
			System.out.println("Holder name: "+fd.getholdernamee());
			System.out.println("Balance" +fd.balance);

		}

		return sbAccountList;

	
	}

}
