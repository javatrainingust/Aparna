package com.training.ustjava;

public class Account {

	private int accountnumber;
	private String holdername;

	public int getaccountnumber() {
		return accountnumber;
	}
	public void setaccountnumber(int accountnumber) {
		this.accountnumber = accountnumber;
	}
	public String getholdernamee() {
		return holdername;
	}
	public void setholdername(String holdername) {
		this.holdername = holdername;
	}

	public Account()
	{
		System.out.println("Inside Base Class no arg constructor");
	}

	public Account(int accountnumber, String holdername)
	{
		System.out.println("Inside Base Class arg constructor " +accountnumber +" " +holdername);
		this.accountnumber=accountnumber;
		this.holdername=holdername;
	}
}