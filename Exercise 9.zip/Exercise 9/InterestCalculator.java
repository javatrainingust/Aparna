package com.training.ustjava;

public class InterestCalculator 
{


	public void FixedAccountInterest(float amount, float duration)
	{
		double rate =0.7;
		double interst= (amount*duration*rate)/100;
		System.out.println("Fixed Accout interst is:" +interst);
	}
}


/*
 * /*public void SavingsAccountInterest(float amount, float duration)
	{
		double rate =0.3;
		double interst= (amount*duration*rate)/100;
		System.out.println("Savings Accout interst is:" +interst);
	}


	public double CalculateInterest(float amount, float duration)
	{
		double rate =0.7;
		double interest= (amount*duration*rate)/100;
		return interest;
	}*/