/**
 * 
 * Instrumentalist
 * 
 * This class implements the interface Performer
 *  
 * 12-10-2020
 *
 */

package com.ust.java.spring;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component("instrumentalist")
public class Instrumentalist implements Performer, Instrument {
	
	@Autowired
	Saxophone sax;
	
	/** 
	 * Getter method for sax
	 */
	public Saxophone getSax() {
		return sax;
	}
	
	/** 
	 * Setter method for sax
	 */
	public void setSax(Saxophone saxophone) {
		sax = saxophone;
	}
	
	/**
	 * Implementation of method in Performer Interface
	 * @throws Exception 
	 */

	public void perform()  {
		
		sax.play();
		System.out.println("Song is sung");
	}

	public void play() {
		
		System.out.println("Played");
		
	}

}
