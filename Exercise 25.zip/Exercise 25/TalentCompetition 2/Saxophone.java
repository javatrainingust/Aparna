/**
 * Saxophone
 * 
 * This class implements the interface Instrument
 *  
 * 12-10-2020
 */

package com.ust.java.spring;

import org.springframework.stereotype.Component;

@Component
public class Saxophone implements Instrument {

	public void play() {
		
		System.out.println("Saxophone is played");

	}

}
